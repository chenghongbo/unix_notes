---
title: About
author: acheng
layout: page
date: 2011-09-30
---
&nbsp;

**可達書院提供信息技术和开源软件培训。**

我们认为可达书院的培训和其他培训的不同之处在于，所有的课程都是基于IT实战经验制作，而不仅仅是照本宣科的技术文档的翻版。

可达书院有免费的视频教程网站，大家可以先体验一下： [www.kdump.org][1]

[hr]

**为什么学习IT知识**

可达书院的目标不是培养IT技术工人。

IT技术可以让你的工作和生活更加高效；可以助你实现自己的生活目标；可以帮助你的企业降低成本，提高生产率。如果你知道如何利用它。

当然，你也可以把它作为一个谋生的手段，或者降低运营成本的方式。

[hr]

**培训科目**

可达书院目前提供一下培训：

[unordered_list style=&#8221;arrow&#8221;]

  * 操作系统管理（Ubuntu/CentOS/Redhat Linux，OpenBSD, Solaris/OpenIndiana)
  * TCP/IP基础
  * IPv6
  * DNS/DHCP
  * Postfix/Sendmail邮件系统
  * Perl/Shell编程
  * 操作系统原理
  * Apache/Nginx Web服务器
  * WordPress/Drupal 内容管理系统（CMS）
  * IT英语
  * &#8230;&#8230;

[/unordered_list]

 [1]: http://www.kdump.org