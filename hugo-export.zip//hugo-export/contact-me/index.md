---
title: contact
author: acheng
layout: page
date: 2011-09-29
---
如果你对可达书院有建议或意见，请发邮件给我们：

[contact_form email=&#8221;acheng@kdump.cn&#8221; subject=&#8221;可达书院，我有话要说&#8221;]