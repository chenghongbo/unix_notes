---
title: BIND错误及修正
author: acheng
layout: post
date: 2010-04-29
excerpt: |
  |
    今天的工作中需要添加大概40条DNS记录，于是就把相应的IP和主机名放在excel里处理了一下，然后粘贴到数据文件里。没想到重启BIND服务器时报错，如下：
    
    root@sol-dns2:/apps/bind # named-checkzone example.com /apps/bind/db.example.com
    dns_master_load: /apps/bind/db.example.com:5944: ignoring out-of-zone data (edc-ene19.exampl.com)
    dns_master_load: /apps/bind/db.example.com:5945: ignoring out-of-zone data (edc-ene19-ilo.exampl.com)
    dns_master_load: /apps/bind/db.example.com:5946: ignoring out-of-zone data (edc-ene20.exampl.com)
    dns_master_load: /apps/bind/db.example.com:5947: ignoring out-of-zone data (edc-ene20-ilo.exampl.com)
url: /blog/named-bad-dotted-quad/
categories:
  - blog
  - 开源应用
tags:
  - news
---
今天的工作中需要添加大概40条DNS记录，于是就把相应的IP和主机名放在excel里处理了一下，然后粘贴到数据文件里。没想到重启BIND服务器时报错，如下：

root@sol-dns2:/apps/bind # named-checkzone example.com /apps/bind/db.example.com  
dns\_master\_load: /apps/bind/db.example.com:5944: ignoring out-of-zone data (edc-ene19.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5945: ignoring out-of-zone data (edc-ene19-ilo.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5946: ignoring out-of-zone data (edc-ene20.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5947: ignoring out-of-zone data (edc-ene20-ilo.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5948: ignoring out-of-zone data (sol-ene24.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5949: ignoring out-of-zone data (sol-ene24-ilo.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5950: ignoring out-of-zone data (sol-ene25.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5951: ignoring out-of-zone data (sol-ene25-ilo.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5952: ignoring out-of-zone data (sol-ene26.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5953: ignoring out-of-zone data (sol-ene26-ilo.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5954: ignoring out-of-zone data (sol-ene27.exampl.com)  
dns\_master\_load: /apps/bind/db.example.com:5955: ignoring out-of-zone data (sol-ene27-ilo.exampl.com)  
dns\_rdata\_fromtext: /apps/bind/db.example.com:5960: near &#8216;10.15.141.144    &#8216;: bad dotted quad  
dns\_rdata\_fromtext: /apps/bind/db.example.com:5961: near &#8216;10.15.141.145 &#8216;: bad dotted quad  
dns\_rdata\_fromtext: /apps/bind/db.example.com:5964: near &#8216;10.15.141.148 &#8216;: bad dotted quad  
dns\_rdata\_fromtext: /apps/bind/db.example.com:5967: near &#8216;10.15.43.251 &#8216;: bad dotted quad  
zone example.com/IN: loading master file /apps/bind/db.example.com: bad dotted quad

仔细看了一下，对于“out-of-zone data&#8221;类型的错误，是因为拼写错误导致的，把example.com写成了exampl.com，修改过来即可。对于&#8221;bad dotted quad&#8221;类型的错误，是相应的行最后有些看不见的空格导致的。把那些空格删掉后，重新用named-checkzone检查数据文件，一切ok了。