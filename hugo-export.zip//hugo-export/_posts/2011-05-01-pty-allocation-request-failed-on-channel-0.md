---
title: PTY allocation request failed on channel 0
author: acheng
layout: post
date: 2011-05-01
url: /blog/pty-allocation-request-failed-on-channel-0/
categories:
  - blog
  - Linux
---
一台RHEL5的服务器，我在运行了一个脚本之后重启一测试脚本的效果。没想到重启后SSH连接的时候报错，无法登录。

SSH连接在输入密码后显示：

PTY allocation request failed on channel 0

根据这个[链接][1];，使用 &#8220;ssh ${user}@${host} &#8216;/bin/bash -i'&#8221;命令来登陆即可进入。

其中${user}是你登陆用的账户名，${host}是你要登录的服务器的名称。&#8217;/bin/bash -i&#8217;的部分则是告诉SSH，连接建立后以互动方式运行/bin/bash这个命令。

果然凑效。

登陆后发现脚本将/etc/fstab中的根节点（/）给搞乱了。根据备份的fstab恢复后再次重启。问题不再出现。

 [1]: http://log.dongsheng.org/2010/03/13/pty-allocation-request-failed-on-channel-0/