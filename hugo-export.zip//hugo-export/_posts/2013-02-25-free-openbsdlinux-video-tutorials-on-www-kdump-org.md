---
title: 'www.kdump.org: 可达讲堂 BSD/UNIX/Linux视频'
author: acheng
layout: post
date: 2013-02-25
url: /blog/free-openbsdlinux-video-tutorials-on-www-kdump-org/
categories:
  - SLIDES
---
[<img class="alignleft size-full wp-image-1841" alt="Blue-Round-Player" src="http://www.kdump.cn/wp-content/uploads/2013/02/Blue-Round-Player.jpg" width="680" height="500" />][1]

进入[www.kdump.org][1]

 [1]: http://www.kdump.org