---
title: Putty设置OpenSSH公钥验证
author: acheng
layout: post
date: 2012-08-15
url: /blog/putty_and_openssh_public_key_auth/
categories:
  - DragonFlyBSD
  - 系统管理
tags:
  - DragonFlyBSD
---
OpenSSH公钥验证又称为无密码验证。DragonFlyBSD默认只接受公钥验证，今天就简单谈一下如何使用Putty以公钥验证的方式登录DragonFlyBSD。

设置公钥验证的逻辑很简单：  
1. 首先生成一对密钥（公、私密钥）  
2. 将公钥的内容放入目标用户主目录下.ssh/authorized_keys文件中  
3. 使用SSH客户端登录时，指定使用相应的私钥进行验证

再来谈一下实际的设置。假定的场景是，在一台Windows系统上，使用Putty登录到DragonFlyBSD机器上。

由于Putty和OpenSSH的密要格式不同，我将使用Puttygen.exe程序来生成密钥对。

<div class="sb_info">
  在Windows上<br /> 1. 下载<a href="http://www.chiark.greenend.org.uk/~sgtatham/putty/download.html">Puttygen.exe</a>程序<br /> 2. 运行Puttygen.exe，点击“Generate”，接受默认设置生成RSA公钥对。生成密钥对需要一点时间，在Puttygen程序的空白处随意移动鼠标以加快进度<br /> 3. 密钥生成后，将其顶部的文本复制并保存到一个文本文件中（即顶部标志为“Public key for pasting into OpenSSH authorized_keys file:&#8221;中的内容）。<br /> 4. 点击”Save Private Key“按钮，保存私钥。程序提示时，确认不用PassPhrase保护私钥<br /> 在DragonFlyBSD上：<br /> 5. 如果你还没有创建相应的用户，使用adduser命令创建一个用户<br /> 6. 在DragonFlyBSD上以此用户登录（控制台）<br /> 7. 在用户主目录下生成.ssh目录： mkdir .ssh<br /> 8. 由于此时DragonFlyBSD不接受SSH登录，需要启动FTPD，从而使用ftp上传公钥文件.<br /> 以root用户，运行：/usr/libexec/ftpd -D</p> 
  
  <p>
    返回到Windows机器上<br /> 9. 在命令行下，以ftp方式登录DragonFlyBSD。用户名/密码就是用刚才以adduser命令创建的用户名和密码<br /> 10. 将第3步中保存的文本文件上传到DragonFlyBSD上
  </p>
  
  <p>
    回到DragonFlyBSD上：
  </p>
  
  <p>
    11. 假定刚才上传的文件名为key.txt，运行如下命令： cat key.txt >> ~/.ssh/authorized_keys
  </p>
  
  <p>
    再次回到Windows机器上
  </p>
  
  <p>
    12. 打开Putty，在其左侧的SSH选项下有一个&#8221;Auth&#8221;，点击“Auth”后，右侧窗格会有一个“Private key file for authentication&#8221;选项，点击对应的”Browse“按钮，找到第4步中保存的私钥(.ppk格式）并加载<br /> 13. 使用Putty登录到DragonFlyBSD，用户名后应该就可以登录了。
  </p>
</div>