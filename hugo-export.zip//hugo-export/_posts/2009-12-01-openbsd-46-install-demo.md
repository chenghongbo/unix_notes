---
title: OpenBSD4.6 installation demo
author: acheng
layout: post
date: 2009-12-01
excerpt: 'OpenBSD 4.6于今年10月中正式发布。和前一版相比，安装过程变得更方便，增加了生成用户，禁用root SSH登录，而且增加了推荐的分区格式，对很多用户来说都是很方便的。以前的手工分区还是有一点复杂的。 <br /> <embed src="http://player.youku.com/player.php/sid/XMTM1MTMyNTUy/v.swf" quality="high" width="680" height="480" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash"></embed>'
url: /blog/openbsd-46-install-demo/
categories:
  - 视频
tags:
  - sysadmin
---
OpenBSD 4.6于今年10月中正式发布。和前一版相比，安装过程变得更方便，增加了生成用户，禁用root SSH登录，而且增加了推荐的分区格式，对很多用户来说都是很方便的。以前的手工分区还是有一点复杂的。   


<embed src="http://player.youku.com/player.php/sid/XMTM1MTMyNTUy/v.swf" quality="high" width="680" height="480" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash">
</embed>