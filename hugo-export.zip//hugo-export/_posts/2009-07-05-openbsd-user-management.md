---
title: openbsd用户管理
author: acheng
layout: post
date: 2009-07-05
excerpt: |
  OpenBSD的用户及组管理；如何添加、删除用户；账户的批量管理；以及OpenBSD的用户管理相关的一些需要了解的知识。
  <embed src="http://player.youku.com/player.php/sid/XMTA0MjY0NzI0/v.swf" quality="high" width="680" height="480" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash"></embed>
url: /blog/openbsd-user-management/
categories:
  - 视频
tags:
  - samplevideo
  - sysadmin
---
OpenBSD的用户及组管理；如何添加、删除用户；账户的批量管理；以及OpenBSD的用户管理相关的一些需要了解的知识。  


<embed src="http://player.youku.com/player.php/sid/XMTA0MjY0NzI0/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash">
</embed>