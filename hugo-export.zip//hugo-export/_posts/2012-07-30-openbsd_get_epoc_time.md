---
title: OpenBSD上获取EPOC时间
author: acheng
layout: post
date: 2012-07-30
url: /blog/openbsd_get_epoc_time/
categories:
  - blog
  - openbsd
  - 系统管理
tags:
  - openbsd
---
用date +%s即可.  
如果想要把EPOC时间转换成默认的时间格式，则用date -r $epoc_time

<div class="sb_tip">
  root@puffy #date<br /> Mon Jul 30 07:25:06 PDT 2012</p> 
  
  <p>
    root@puffy #date +%s<br /> 1343658310
  </p>
</div>

<div class="sb_info">
  root@puffy #date -r $(date +%s); date<br /> Mon Jul 30 07:25:29 PDT 2012<br /> Mon Jul 30 07:25:29 PDT 2012
</div>