---
title: 在OpenBSD上挂载Windows的共享文件夹
author: acheng
layout: post
date: 2011-07-19
url: /blog/mount_windows_share_on_openbsd/
categories:
  - openbsd
  - 系统管理
tags:
  - cifs
  - openbsd
---
1. 首先，安装sharity-light程序(OpenBSD 4.9, I386平台，其他版本或平台请相应更改此URL地址）  
pkg_add -v ftp://ftp.openbsd.org/pub/OpenBSD/4.9/packages/i386/sharity-light-1.3p0.tgz

2. 完成安装后，运行下面的命令挂载：  
#shlight -n //windows/share /mnt/point

3. 现在，Windows上的共享文件夹（//Windows/share）就被挂载到了/mnt/point(此目录在挂载前必须存在）

这里//windows/share是所有人都可以访问的。如果有权限控制，需要用户名和密码的话，可以使用：  
#shlight //windows/share /mnt/point -U username -P password

更详细的用法，请参考下面两个文件：

/usr/local/share/doc/Sharity-Light/FAQ  
/usr/local/share/doc/Sharity-Light/README

当然，你也可以安装/使用Samba软件来实现，但不如shlight来的简单