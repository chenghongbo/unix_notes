---
title: OpenBSD 5.7 CD/T-shirt预订
author: acheng
layout: post
date: 2013-02-25
url: /blog/order-t-shirt-and-cd-for-the-coming-openbsd-5-3/
wp_review_location:
  - bottom
wp_review_desc_title:
  - 摘要
wp_review_color:
  - '#1e73be'
wp_review_fontcolor:
  - '#555555'
wp_review_bgcolor1:
  - '#e7e7e7'
wp_review_bgcolor2:
  - '#ffffff'
wp_review_bordercolor:
  - '#e7e7e7'
categories:
  - SLIDES
---
[<img class="alignleft size-full wp-image-1830" src="http://www.kdump.cn/wp-content/uploads/2013/02/t-shirt.png" alt="t-shirt" width="600" height="345" />][1]  
OpenBSD 5.7将于今年5月1日发布，想要订购OpenBSD T恤衫或CD的朋友，请参考下面的这个链接：[button link=&#8221;http://www.kdump.cn/store/index.php?route=product/product&product_id=61&#8243; size=&#8221;large&#8221; style=&#8221;info&#8221; window=&#8221;yes&#8221;]查看详情[/button]

或通过下面的联系表单发邮件给我：

[contact_form email=&#8221;acheng@kdump.cn&#8221; subject=&#8221;OpenBSD CD/tshirt&#8221;]

&nbsp;

 [1]: http://www.kdump.cn/store/index.php?route=product/product&product_id=61