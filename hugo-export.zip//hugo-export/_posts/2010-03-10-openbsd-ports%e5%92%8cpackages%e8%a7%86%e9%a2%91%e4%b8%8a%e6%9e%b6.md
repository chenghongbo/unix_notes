---
title: OpenBSD ports和packages视频上架
author: acheng
layout: post
date: 2010-03-10
excerpt: 商品目录中添加了OpenBSD ports和packages视频
url: /blog/openbsd-ports%e5%92%8cpackages%e8%a7%86%e9%a2%91%e4%b8%8a%e6%9e%b6/
categories:
  - news
tags:
  - news
---
商品目录中添加了OpenBSD ports和packages视频