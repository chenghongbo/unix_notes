---
title: 获取Solaris UPDATE信息
author: acheng
layout: post
date: 2012-02-21
url: /blog/find-solaris-update-number/
categories:
  - Solaris
tags:
  - Solaris
---
Solaris上，uname -r命令可以给出发行版本号（release）。如果想要获得它的update信息（如 Solaris 10 update 1/update 3等等），需要通过/etc/release文件：

solaris# cat /etc/release  
Solaris 10 10/09 s10x\_u8wos\_08a X86  
Copyright 2009 Sun Microsystems, Inc.  All Rights Reserved.  
Use is subject to license terms.  
Assembled 16 September 2009

&nbsp;

其中，u8wos_08a中的u8就表示此系统的update号为8，即u8