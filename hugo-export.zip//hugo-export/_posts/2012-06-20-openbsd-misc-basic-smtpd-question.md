---
title: openbsd misc – basic smtpd question
author: acheng
layout: post
date: 2012-06-20
url: /blog/openbsd-misc-basic-smtpd-question/
categories:
  - openbsd
  - 系统管理
---
// Thread started by bofh

Hi,  
Trying to migrate from my 4.4 to 5.1. Thought I&#8217;d go with smtpd. Is  
this config good? I want all email for my domain to be delivered on  
this box, and for this box to send email out.

wan_if = &#8220;em0&#8243;  
lan_if = &#8220;fxp0&#8243;

listen on lo0  
listen on $lan_if  
listen on \_wan\_if

map &#8220;aliases&#8221; { source db &#8220;/etc/mail/aliases.db&#8221; }

accept for local alias aliases deliver to mbox  
accept for domain &#8220;*.domain1.com&#8221; deliver to mbox  
accept for domain &#8220;*.domain2.org&#8221; deliver to mbox  
accept from 10.1.1.0/24 relay

I&#8217;m also using spamd with default settings as delivered on 5.1, just  
uncommenting out the spamd pieces in /etc/pf.conf &#8211; there&#8217;d be no  
impact here right?

Thanks!