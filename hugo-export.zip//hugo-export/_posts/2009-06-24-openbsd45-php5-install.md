---
title: openbsd上安装php5
author: acheng
layout: post
date: 2009-06-24
excerpt: |
  这个视频讲述如何在openbsd4.5上通过package安装php-5.2.8。
  <embed src="http://player.youku.com/player.php/sid/XMTA1ODg4NzEy/v.swf" quality="high" width="680" height="480" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash"></embed>
url: /blog/openbsd45-php5-install/
categories:
  - 视频
tags:
  - samplevideo
  - sysadmin
---
这个视频讲述如何在openbsd4.5上通过package安装php-5.2.8。  


<embed src="http://player.youku.com/player.php/sid/XMTA1ODg4NzEy/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash">
</embed>