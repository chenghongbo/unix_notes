---
title: OpenBSD预备课程 – 常用文件命令
author: acheng
layout: post
date: 2010-07-16
excerpt: |
  |
    在这个视频中讨论的是文件相关的常用的命令，比如说列出某个目录下文件列表的“ls”命令，查看文件的“cat”命令等。
    
    Unix中，“一切皆文件”，所有的东西都以文件的形式存在，包括硬件设备也一样。因此这些命令都是管理OpenBSD或其他Unix系统的基础。
url: /blog/pp-file-commands/
categories:
  - 视频
tags:
  - samplevideo
---
在这个视频中讨论的是文件相关的常用的命令，比如说列出某个目录下文件列表的“ls”命令，查看文件的“cat”命令等。

Unix中，“一切皆文件”，所有的东西都以文件的形式存在，包括硬件设备也一样。因此这些命令都是管理OpenBSD或其他Unix系统的基础。

<div id="jw_wrap_1279274489468">
</div>

&nbsp;