---
title: install flvtool2 on OpenBSD 5.0
author: acheng
layout: post
date: 2011-11-25
url: /blog/install-flvtool2-on-openbsd-5-0/
categories:
  - openbsd
  - 系统管理
---
cd /usr/src/  
pkg_add -v ruby-1.8  
ftp http://rubyforge.org/frs/download.php/17497/flvtool2-1.0.6.tgz  
tar xzf flvtool2-1.0.6.tgz  
cd flvtool2-1.0.6  
ruby setup.rb config  
ruby setup.rb setup  
ruby setup.rb install  
cd ..