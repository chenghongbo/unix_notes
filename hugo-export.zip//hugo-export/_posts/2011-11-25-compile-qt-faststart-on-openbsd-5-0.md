---
title: compile qt-faststart on openbsd 5.0
author: acheng
layout: post
date: 2011-11-25
url: /blog/compile-qt-faststart-on-openbsd-5-0/
categories:
  - openbsd
  - 开源应用
---
&nbsp;

git clone git://git.videolan.org/ffmpeg.git

<pre> cd ffmpeg

 ./configure --enable-gpl --enable-version3 --enable-nonfree --enable-postproc \
--enable-libfaac --enable-libmp3lame --enable-libopencore-amrnb \
--enable-libopencore-amrwb --enable-libtheora --enable-libvorbis \
--enable-libvpx --enable-libx264 --enable-libxvid --enable-x11grab

（上面的参数需要预先安装相应的codec/Library。或者直接运行./configure）
 make
make tools/qt-faststart</pre>

cp -a tools/qt-faststart /usr/local/bin/