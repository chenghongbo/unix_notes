---
title: OpenBSD Gnome桌面环境虚拟机
author: acheng
layout: post
date: 2012-03-20
url: /blog/gnome_on_openbsd_virtualbox_image/
categories:
  - blog
  - openbsd
---
上周在VirtualBox虚拟机上安装了OpenBSD 5.0 + Gnome 2.3，想要尝试一下OpenBSD用于桌面系统的可行性。配置完成以后，我把这个虚拟机从VirtualBox中导出，放在115的网盘上，希望有更多的朋友试一下OpenBSD，而且用的人越多，也就更容易发现其中的不足之处。

先上几个截屏，更直观一点。

<div style="width: 624px" class="wp-caption alignnone">
  <img title="桌面截图" src="http://p13.freep.cn/p.aspx?u=v20_p13_photo_1203201054453635_0.jpg" alt="桌面截图" width="614" height="460" />
  
  <p class="wp-caption-text">
    桌面截图
  </p>
</div>

&nbsp;

<div style="width: 624px" class="wp-caption alignnone">
  <img class=" " title="文件浏览器截图" src="http://p13.freep.cn/p.aspx?u=v20_p13_photo_1203201056146797_0.jpg" alt="" width="614" height="460" />
  
  <p class="wp-caption-text">
    文件浏览器截图（Evolution Gnome主题）
  </p>
</div>

<div style="width: 624px" class="wp-caption alignnone">
  <img title="FreeOSX Gnome主题截图" src="http://p13.freep.cn/p.aspx?u=v20_p13_photo_1203201057409919_0.jpg" alt="FreeOSX Gnome主题截图" width="614" height="460" />
  
  <p class="wp-caption-text">
    FreeOSX Gnome主题截图
  </p>
</div>

&nbsp;

现在简单汇总介绍一下：

**1. 这个东西是&#8230;?**

一个VirtualBox虚拟机文件。

**2. 这个东西有什么用处？**

它提供一个现成的OpenBSD 5.0加上Gnome 2.3的桌面环境

这个虚拟机是为那些想要试用一下OpenBSD，但还没有准备好在电脑安装它的朋友准备的。将这个虚拟机文件导入到VirtualBox中以后就有了一个现成的OpenBSD 5.0加上Gnome 2.3的桌面环境

**3. 为什么我可能会对它感兴趣？**

如果你不准备尝试OpenBSD系统，或者你对OpenBSD系统已经很熟悉，你很可能不会对这个文件感兴趣

**4. OpenBSD？**

和Windows XP/Windows 7一样，OpenBSD是一个操作系统；和CentOS/Ubuntu Linux发行版一样，它是一个免费的UNIX类操作系统；和它们都不一样的是，OpenBSD是一个专注于安全的操作系统。强调完全的开放源代码（BSD授权协议，不同于Linux的GPL协议）、代码质量和主动安全。

http://www.openbsd.org

**5. 如何使用它？**

很简单，几步就可以完成。

*a>从下面的链接上下载并安装VirtualBox软件（4.1.10或更高版本）*

https://www.virtualbox.org/wiki/Downloads

*b> 下载这个虚拟机文件（分割成了四个部分）*

下载链接：

part1:  http://115.com/file/c2gldx6i  
part2:  http://115.com/file/anzqhsgn  
part3:  http://115.com/file/dp6nx72i  
part4:  http://115.com/file/e7y6wsxs

&nbsp;

*c>下载完成后使用使用[7-zip][1]软件解压*

解压后会得到一个名为OpenBSD5.0\_Gnome2.3\_I386.ova的文件。

合并后的ova文件校验和：

$ md5 ./OpenBSD5.0\_Gnome2.3\_I386.ova;sha1 ./OpenBSD5.0\_Gnome2.3\_I386.ova  
MD5 (./OpenBSD5.0\_Gnome2.3\_I386.ova) = e410b0c3350a48e935b0cee9de594d71  
SHA1 (./OpenBSD5.0\_Gnome2.3\_I386.ova) = 5eb97bb7e4b14e22904430a989943d9ab75e3b35

*d>将此ova文件导入到virtualbox中，即可使用。*

打开VirtualBox软件，去“File” > &#8220;Import Appliance&#8221;，然后找到这个ova文件，导入即可。

*e>登录*

用户名: puffy

密码：kdump.cn

获取root权限：在命令行下输入sudo su &#8211;

*f>如果需要输入中文，按“Ctrl+空格”键可激活Fcitx中文输入法，再按“Ctrl+shift”键切换到拼音输入*

**6>关于中文支持**

由于OpenBSD内核不支持UTF-8编码，Gnome菜单均为英文。可以查看中文文件及输入中文

7>其它

a. 如果你不喜欢默认的Evolution主题，可以通过“system&#8221; > &#8220;Appreance&#8221;来选择其他主题。

b. 系统在右上角时钟的位置会显示天气。默认设置为上海，你可以点击时钟，进行修改。

c. 如果你想使用VMWare而非VirtualBox，可以等稍后发布的一个安装用的ISO文件，可以用它进行安装

d. 安装其他软件：

OpenBSD没有图形界面来进行软件管理。但它的命令行工具同样方便。只需在命令行下输入pkg\_add -v pkg\_name即可（需root权限）

浏览http://ftp5.usa.openbsd.org/pub/OpenBSD/snapshots/packages/i386/可以找到所有可用的软件包

e. 未尽事宜，请留言或发邮件给我

acheng[at]kdump.cn

能够访问flickr的朋友，可以到 <http://www.flickr.com/photos/kdump/sets/72157629625073597/>查看更多截图。

acheng

2012/03/19

 [1]: http://www-7-zip.org