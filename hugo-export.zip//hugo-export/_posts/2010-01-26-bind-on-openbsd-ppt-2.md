---
title: BIND on OpenBSD PPT
author: acheng
layout: post
date: 2010-01-26
excerpt: |
  Here is the PPT file used to record the BIND on OpenBSD video. Written in English.
  Hope you like it.
url: /blog/bind-on-openbsd-ppt-2/
categories:
  - 其它
---
Here is the PPT file used to record the BIND on OpenBSD video. Written in English.  
Hope you like it.