---
title: DragonFlyBSD 3.0.2上安装Apache
author: acheng
layout: post
date: 2012-08-12
url: /blog/install_apache_on_dragonflybsd3-0-2/
categories:
  - DragonFlyBSD
tags:
  - DragonFlyBSD
---
上面一篇介绍了一下DragonFlyBSD上的软件管理，今天就来安装Apache。

如果你时间紧迫，先看一下摘要：

<div class="sb_info">
  1. pkg_radd -v apache-2.2.21nb7<br /> 2. cp /usr/pkg/share/examples/rc.d/apache /etc/rc.d/<br /> 3. 添加apache_enable=&#8221;YES&#8221;到/etc/rc.conf<br /> 4. kldload accf_http<br /> 5. 在/etc/defaults/loader.conf中，将下面两行中的NO改成YES：<br /> accf_data_load=&#8221;NO&#8221; # Wait for data accept filter<br /> accf_http_load=&#8221;NO&#8221; # Wait for full HTTP request accept filter<br /> 6. 根据情况，注释掉httpd.conf中的下面一行：<br /> LoadModule unique_id_module lib/httpd/mod_unique_id.so<br /> 7. /etc/rc.d/apache start<br /> 8. 根据需要，调整自己的httpd.conf配置
</div>

下面开始短话长说。

由于刚开始DragonFlyBSD，不知道它的Apache软件包是什么名字，大致先搜一下吧：

\# pkg_search httpd  
bozohttpd-20111118 Bozotic HTTP server; small and secure  
libmicrohttpd-0.9.17 Small C library to run an HTTP server as part of another app  
&#8230;&#8230;

没有我想找的。再试一次：

\# pkg_search apache  
apache-1.3.42 Apache HTTP (Web) server  
apache-2.0.64nb1 Apache HTTP (Web) server, version 2  
apache-2.2.21nb7 Apache HTTP (Web) server, version 2.2  
apache-ant-1.5.4nb2 &#8220;Apache Project&#8217;s Java-Based make(1) replacement&#8221;  
&#8230;&#8230;

apache-2.2这个看起来还比较接近，虽然不是最新版的&#8230;

pkg_radd -v apache-2.2.21nb7

DBSD (DragonFlyBSD)上，apache的配置文件在/usr/pkg/etc/httpd下，htdocs目录在 /usr/pkg/share/httpd/htdocs/，日志目录在/var/log/httpd/

刚开始没找到它的启动脚本。仔细看了一下软件安装后给出的提示（这一点很重要），脚本是/usr/pkg/share/examples/rc.d/apache，需要手工复制到/etc/rc.d/目录下。

复制完成后，使用/etc/rc.d/apache start启动失败，提示所/etc/rc.conf设置不对。

在/etc/rc.conf中加入apache\_enable=&#8221;YES&#8221;后，重试启动，依然失败，报一个http\_ready的错误:

\[Tue Aug 11 16:06:39 2012] [warn\] (2)No such file or directory: Failed to enable the &#8216;httpready&#8217; Accept Filter

依稀记得几年前在FreeBSD上也碰到过类似的错误。google后发现需要如下操作：

1. 运行：kldload accf_http  
2. 在/etc/defaults/loader.conf中，将下面两行中的NO改成YES：  
accf\_data\_load=&#8221;NO&#8221; # Wait for data accept filter  
accf\_http\_load=&#8221;NO&#8221; # Wait for full HTTP request accept filter

重新启动，依然有错：

\[Tue Aug 11 16:37:05 2012] [alert\] (EAI 8)hostname nor servname provided, or not known: mod\_unique\_id: unable to find IPv4 address of &#8220;&#8221;  
Configuration Failed

google了一下，原来是hostname需要在配置的DNS服务器上能解析。于是我把httpd.conf中的下面这一行注释掉，再此尝试启动就OK了：

LoadModule unique\_id\_module lib/httpd/mod\_unique\_id.so

后面的就是APACHE自己的配置了。每个人的需求不同，这里不谈。