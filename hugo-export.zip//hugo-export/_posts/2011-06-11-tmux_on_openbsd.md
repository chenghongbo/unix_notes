---
title: TMUX on OpenBSD
author: acheng
layout: post
date: 2011-06-11
url: /blog/tmux_on_openbsd/
enclosure:
  - |
    |
        http://www.kdump.cn/wp-content/uploads/2011/06/tmux.flv
        0
        video/x-flv
        
categories:
  - openbsd
  - 视频
tags:
  - tmux
---
TMUX是一个终端复用软件，和Linux下的Screen软件类似。

TMUX可以让一次登陆打开多个会话窗口，最重要的是，它可以让你的SSH连接不慎中断的情况下保持会话在后台继续运行；而且它也可以实现命令行下的远程桌面共享 <img src="http://www.kdump.cn/wp-includes/images/smilies/icon_smile.gif" alt=":-)" class="wp-smiley" />

这个视频也是“OpenBSD新手入门”视频DVD的一部分，发布在网站上用于展示。

为了便于网上观看，视频被转为flv格式，因此质量有所降低。

<div style="width: 640px; " class="wp-video">
  <!--[if lt IE 9]><![endif]--><video class="wp-video-shortcode" id="video-651-1" width="640" height="480" preload="metadata" controls="controls"><source type="video/x-flv" src="http://www.kdump.cn/wp-content/uploads/2011/06/tmux.flv?_=1" />
  
  <a href="http://www.kdump.cn/wp-content/uploads/2011/06/tmux.flv">http://www.kdump.cn/wp-content/uploads/2011/06/tmux.flv</a></video>
</div>