---
title: DragonFlyBSD 3.0.2上安装MySQL
author: acheng
layout: post
date: 2012-08-13
url: /blog/install_mysql_on_dragonflybsd3-0-2/
categories:
  - DragonFlyBSD
tags:
  - DragonFlyBSD
---
MySQL服务器的安装比较简单，摘要如下：

1. pkg_radd mysql-server-5.1.60  
2. cp /usr/pkg/share/examples/rc.d/mysqld /etc/rc.d/  
3. 在/etc/rc.conf中添加mysqld_enable=&#8221;YES&#8221;  
4. /etc/rc.d/mysqld start  
5. 运行/usr/pkg/bin/mysql\_secure\_installation，跟据提示设置root账户密码，删除不必要的一些东东

<div class="sb_tip">
  如果你准备安装php，不要安装mysql的5.5版。目前有兼容性问题。
</div>