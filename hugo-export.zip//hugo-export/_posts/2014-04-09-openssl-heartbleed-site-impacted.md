---
title: 'OpenSSL HeartBleed: Is your site impacted?'
author: acheng
layout: post
date: 2014-04-09
url: /blog/openssl-heartbleed-site-impacted/
categories:
  - blog
  - Featured
  - 网络安全
---
最近爆出的OpenSSL heartbleed安全漏洞对互联网的安全又敲了一次警钟。鉴于网络已经成为现代人生活中不可或缺的一部分，大家也只能是提高警惕，而且相信这也不会是最后一个安全事件。

根据媒体报道，中国境内受到影响的服务器有30000个左右，不知道这个数字是否准确，考虑到受到影响的最早的OpenSSL版本1.0.1d发布于2013年2月5号，距今一年零二个月，这个数字并不算少。

那么对于普通用户，如果你有网购的习惯，那么在再次登陆之前先确认相关电商网站（包括电子银行业务）已经修复此问题，然后登陆，修改自己的密码，以确保安全。

对于网站维护者，首先确认你系统上的OpenSSL是否受到影响，如果是，尽快升级到已解决此问题的OpenSSL版本（如1.0.1g）。

如何察看你的OpenSSL版本：

[acheng@puffy ~]$ openssl version  
OpenSSL 1.0.0f 4 Jan 2012

漏洞的发现者关于此问题的介绍：

<http://heartbleed.com/>

OpenSSL官方关于此漏洞的介绍：

<http://www.openssl.org/news/secadv_20140407.txt>

<pre>OpenSSL Security Advisory [07 Apr 2014]
========================================

TLS heartbeat read overrun (CVE-2014-0160)
==========================================

A missing bounds check in the handling of the TLS heartbeat extension can be
used to reveal up to 64k of memory to a connected client or server.

Only 1.0.1 and 1.0.2-beta releases of OpenSSL are affected including
1.0.1f and 1.0.2-beta1.

Thanks for Neel Mehta of Google Security for discovering this bug and to
Adam Langley &lt;agl@chromium.org&gt; and Bodo Moeller &lt;bmoeller@acm.org&gt; for
preparing the fix.

Affected users should upgrade to OpenSSL 1.0.1g. Users unable to immediately
upgrade can alternatively recompile OpenSSL with -DOPENSSL_NO_HEARTBEATS.

1.0.2 will be fixed in 1.0.2-beta2.</pre>