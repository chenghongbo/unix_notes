---
title: OpenBSD预备课程 – 如何连接OpenBSD服务器
author: acheng
layout: post
date: 2010-07-10
excerpt: |
  |
    为了帮助哪些想要学习Unix/OpenBSD，但是又不知如何入手的朋友，我特地制作了一个OpenBSD预备课程系列，希望能够解答一些初期的疑问，也希望这些视频可以帮助这些朋友顺利的开始Unix/OpenBSD的学习之旅。
    
    虽然名为OpenBSD预备课程，它同样也适用于想要学习其他Unix/Linux的朋友。
    
    这个视频为第一篇，介绍如何连接到一个安装完成的OpenBSD或者是Unix服务器。至于如何安装，请参考<a href="/content/openbsd/openbsd46-installation">OpenBSD4.6安装演示</a>
    
    OpenBSD或其他Unix服务器安装完成以后，我们一般不会每天到机房去操作它，而是通过SSH客户端软件连接到这台服务器进行相应的操作和维护。这个视频就是介绍如何进行连接。
url: /blog/preparation-ssh-client/
categories:
  - 视频
tags:
  - samplevideo
---
为了帮助哪些想要学习Unix/OpenBSD，但是又不知如何入手的朋友，我特地制作了一个OpenBSD预备课程系列，希望能够解答一些初期的疑问，也希望这些视频可以帮助这些朋友顺利的开始Unix/OpenBSD的学习之旅。

虽然名为OpenBSD预备课程，它同样也适用于想要学习其他Unix/Linux的朋友。

这个视频为第一篇，介绍如何连接到一个安装完成的OpenBSD或者是Unix服务器。至于如何安装，请参考[OpenBSD4.6安装演示][1]

OpenBSD或其他Unix服务器安装完成以后，我们一般不会每天到机房去操作它，而是通过SSH客户端软件连接到这台服务器进行相应的操作和维护。这个视频就是介绍如何进行连接。

  
<!--break-->

 [1]: /content/openbsd/openbsd46-installation