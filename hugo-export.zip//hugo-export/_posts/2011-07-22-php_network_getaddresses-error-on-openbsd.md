---
title: php_network_getaddresses errors on OpenBSD
author: acheng
layout: post
date: 2011-07-22
url: /blog/php_network_getaddresses-error-on-openbsd/
categories:
  - openbsd
  - 开源应用
tags:
  - openbsd
  - php
---
如果你使用OpenBSD来为你的Wordpress或drupal的CMS提供主机服务，你很可能会碰到类似下面的错误消息：

Uh-oh, we were unable to verify your API Key. Please check them and try again!  
The server said:Could not connect (ERR 0: php\_network\_getaddresses: getaddrinfo failed: non-recoverable failure in name resolution)

我的OpenBSD服务器名称解析很正常，为什么还会报这个错误呢？

这是因为OpenBSD上的Apache默认是chroot到/var/www目录下的，而PHP脚本在名称解析时需要用到/etc/resolv.conf文件中配置的名称服务器。在chroot的情况下，PHP程序看到的“/”目录其实是实际的/var/www目录。

因此解决这个问题就很简单了：

`mkdir /var/www/etc/<br />
cp /etc/resolv.conf /var/www/etc/<br />
apachectl stop<br />
apachectl start`