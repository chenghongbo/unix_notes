---
title: OpenBSD上的彩色LS输出
author: acheng
layout: post
date: 2012-08-06
url: /blog/ls_output_with_color_on_openbsd/
categories:
  - blog
  - openbsd
  - 系统管理
tags:
  - openbsd
---
OpenBSD上的ls命令输出是黑白的，没有对不同的文件类型使用不同的颜色来区分。如果想要使用彩色，可以安装colorls这个程序。它就相当于一个“彩色的ls”（要使用colorls的-G参数）。

可以使用下面的操作来完成：

<div class="sb_tip">
  1. 安装colorls<br /> pkg_add -v colorls (假定你的PKG_PATH参数已经设定好了）</p> 
  
  <p>
    2. 设定命令别名<br /> alias ls=&#8217;colorls -G&#8217;
  </p>
  
  <p>
    3. 把上面那一行添加到自己的.profile文件中，免得下次登录还得运行alias命令
  </p>
</div>