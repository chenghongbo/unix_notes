---
title: OpenBSD预备课程 – SHELL简介
author: acheng
layout: post
date: 2010-07-10
excerpt: SHELL是使用OpenBSD及其他Unix类服务器的必由之路，是用户和操作系统/计算机硬件交互的界面。本视频对SHELL做一个入门简介。
url: /blog/preparation-shells/
categories:
  - 视频
tags:
  - samplevideo
---
SHELL是使用OpenBSD及其他Unix类服务器的必由之路，是用户和操作系统/计算机硬件交互的界面。本视频对SHELL做一个入门简介。

<div id="jw_wrap_1278743032316">
  <span></span>
</div>

&nbsp;