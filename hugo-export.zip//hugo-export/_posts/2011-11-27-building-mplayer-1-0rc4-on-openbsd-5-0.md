---
title: building MPlayer-1.0rc4 on openbsd 5.0
author: acheng
layout: post
date: 2011-11-27
url: /blog/building-mplayer-1-0rc4-on-openbsd-5-0/
categories:
  - blog
  - openbsd
  - 开源应用
  - 系统管理
---
首先，建议使用openbsd 的package安装，而不是从源码编译，除非里面的mplayer确实不适用。

source file: <span class="Apple-style-span" style="font-family: Consolas, Monaco, monospace; font-size: 12px; line-height: 18px; white-space: pre;">http://www.mplayerhq.hu/MPlayer/releases/MPlayer-1.0rc2.tar.bz2</span>

&nbsp;

编译之前，先下载：

<pre>http://www2.mplayerhq.hu/MPlayer/releases/codecs/essential-20071007.tar.bz2</pre>

<pre>然后解压至/usr/local/lib/codecs文件夹</pre>

<pre></pre>

configure选项：

&#8211;codecsdir=/usr/local/lib/codecs &#8211;extra-cflags=-I/usr/local/include &#8211;extra-ldflags=-L/usr/local/lib

gmake && gmake install  #（gmake, not make）

&nbsp;

如果出现：

network.h:69: error: redefinition of &#8216;struct sockaddr_storage&#8217;

编辑 libavformat/network.h文件，在文件前面添加：

#define HAVE\_STRUCT\_SOCKADDR_STORAGE 1

&nbsp;

在AMD64平台上，你可能会遇到下面的错误：

<pre>{standard input}: Assembler messages:
{standard input}:18: Error: `ff_h264_lps_range(%eax,%esi,2)' is not a valid 64 bit base/index expression
{standard input}:28: Error: `ff_h264_norm_shift(%esi)' is not a valid 64 bit base/index expression
{standard input}:30: Error: `ff_h264_mlps_state+128(%eax)' is not a valid 64 bit base/index expression
{standard input}:42: Error: `-1(%ebx)' is not a valid 64 bit base/index expression</pre>

<pre>......</pre>

<pre>一个临时的解决方案是：</pre>

<pre>在 libavcodec/h264.h顶部加入；</pre>

<pre>#define HAVE_EBX_AVAILABLE 0</pre>

<pre>参考：<a href="http://web.archiveorange.com/archive/v/bFtHWRep6AGOQUhfzoHN">http://web.archiveorange.com/archive/v/bFtHWRep6AGOQUhfzoHN</a></pre>

&nbsp;

如果编译失败，可能是系统上一些codec没有安装，可参考：

<http://www.vimp.com/en/documentation-faq-article/items/compile-mplayermencoder-on-your-own.html>

&nbsp;

&nbsp;

&nbsp;

&nbsp;