---
title: OpenBSD上手工连接无线网络
author: acheng
layout: post
date: 2012-09-10
url: /blog/openbsd%e4%b8%8a%e6%89%8b%e5%b7%a5%e8%bf%9e%e6%8e%a5%e6%97%a0%e7%ba%bf%e7%bd%91%e7%bb%9c/
categories:
  - openbsd
  - 系统管理
---
有时候需要临时连接到一个无线网络（如咖啡馆内）。在OpenBSD上可以这样做：

<div class="sb_info">
  ifconfig $nic nwid ${network_id} wpakey ${wpa_key}<br /> dhclient $nic
</div>

其中，$nic是无线网卡的名称，${network\_id}是无线网络的SSID，${wpa\_key}是WPA密钥（明文）（假定无线网络使用WPA认证）

注意：  
1. 在命令行上输入明文密钥有被人窥探的风险  
2. 重启后此配置失效，需重新执行命令