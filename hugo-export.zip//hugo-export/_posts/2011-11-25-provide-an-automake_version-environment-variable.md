---
title: Provide an AUTOMAKE_VERSION environment variable
author: acheng
layout: post
date: 2011-11-25
url: /blog/provide-an-automake_version-environment-variable/
categories:
  - openbsd
  - 系统管理
---
在OpenBSD 5.0-current上编译libfaac的时候出现如下问题

[root@cactus /usr/src/faac-1.28]# ./bootstrap  
Provide an AUTOMAKE_VERSION environment variable, please  
Provide an AUTOCONF_VERSION environment variable, please  
Provide an AUTOMAKE_VERSION environment variable, please  
Provide an AUTOCONF_VERSION environment variable, please

&nbsp;

检查一下automake和autoconf的版本：

[root@cactus /usr/src/faac-1.28]# pkg_info | grep auto  
autoconf-2.59p3     automatically configure source code on many Un*x platforms  
autoconf-2.68       automatically configure source code on many Un*x platforms  
automake-1.9.6p8    GNU standards-compliant Makefile generator  
metaauto-1.0        wrapper for gnu auto*

设置相应的变量：

[root@cactus /usr/src/faac-1.28]# export AUTOMAKE_VERSION=1.9  （=1.9.6不行）  
[root@cactus /usr/src/faac-1.28]# export AUTOCONF_VERSION=2.68  
[root@cactus /usr/src/faac-1.28]# ./bootstrap

ok