---
title: openbsd上安装mysql
author: acheng
layout: post
date: 2009-06-20
excerpt: |
  此视频讲述如何在OpenBSD4.5上安装mysql,使用package，而不是port。以及如何设定mysql在系统启动时自动启动，创建实例数据库及用户。
  <embed src='http://player.youku.com/player.php/sid/XMTA1ODk1Njk2/v.swf' quality='high' width='680' height='480' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash'></embed>
url: /blog/mysql-install/
categories:
  - 视频
tags:
  - samplevideo
  - sysadmin
---
此视频讲述如何在OpenBSD4.5上安装mysql,使用package，而不是port。以及如何设定mysql在系统启动时自动启动，创建实例数据库及用户。  


<embed src='http://player.youku.com/player.php/sid/XMTA1ODk1Njk2/v.swf' quality='high' width='480' height='400' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash'>
</embed>