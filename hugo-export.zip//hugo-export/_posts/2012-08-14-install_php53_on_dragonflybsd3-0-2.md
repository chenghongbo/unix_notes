---
title: DragonFlyBSD 3.0.2上安装PHP5.3
author: acheng
layout: post
date: 2012-08-14
url: /blog/install_php53_on_dragonflybsd3-0-2/
categories:
  - DragonFlyBSD
  - 系统管理
tags:
  - DragonFlyBSD
---
1. 安装PHP模块及其常用的扩展，根据自己的需求进行增减：

<div class="sb_info">
  pkg_radd -v ap22-php53-5.3.9nb1 php53-apc-5.3.9.3.1.9nb1 php53-curl-5.3.9nb1 php53-gd-5.3.9nb2 php53-mysql-5.3.9 php53-mysqli-5.3.9 php53-pdo_mysql-5.3.9 php53-suhosin-5.3.9.0.9.33 php53-xsl-5.3.9nb1 php53-xmlrpc-5.3.9 php53-mbstring-5.3.9 php53-json-5.3.9 php53-zlib-5.3.9
</div>

2. 根据软件安装提示，把下面几行添加到/usr/pkg/etc/php.ini中，Dynamic Extensions一节下面：

<div class="sb_info">
  ;;;;;;;;;;;;;;;;;;;;;;;<br /> ; Dynamic Extensions ;<br /> ;;;;;;;;;;;;;;;;;;;;;;</p> 
  
  <p>
    extension=zlib.so<br /> extension=apc.so<br /> extension=iconv.so<br /> extension=curl.so<br /> extension=gd.so<br /> extension=suhosin.so<br /> extension=dom.so<br /> extension=xsl.so<br /> extension=xmlrpc.so<br /> extension=pdo.so<br /> extension=pdo_mysql.so<br /> extension=mysql.so<br /> extension=mysqli.so<br /> extension=json.so<br /> extension=mbstring.so
  </p>
</div>

根据第一步中安装的软件不同，extension也会不同。

3. 把下面两行加入到httpd.conf中的相应位置：

LoadModule php5\_module lib/httpd/mod\_php5.so  
AddHandler application/x-httpd-php .php

4. 重启apache  
apachectl restart

5. 测试PHP  
echo &#8220;<?php phpinfo(); ?>&#8221; | php