---
title: index.txt与OpenBSD安装服务器
author: acheng
layout: post
date: 2012-09-13
url: /blog/index-txt%e4%b8%8eopenbsd%e5%ae%89%e8%a3%85%e6%9c%8d%e5%8a%a1%e5%99%a8/
categories:
  - openbsd
---
由于我的thinkpad x120e没有光驱，而且我也懒得去刻录光盘，因此就在另外一台笔记本上启动了Apache，准备以HTTP方式安装。

将下载好的install52 ISO文件解压到web服务器的根目录下，设置好相应的权限，使用一个已经做好的U盘启动x120e，一切正常。但是当指定笔记本为安装服务器时，安装程序报告找不到安装需要的文件。使用浏览器访问相应目录，则一切正常，安装所需文件就在那个目录下。不解。

尝试了几次依然不行。于是就到web服务器的错误日志中看了一下，发现了一个“index.txt&#8221;文件不存在的错误，这才恍然大悟，原来ISO文件中不包含这个index.txt文件，因此，到那些TGZ文件所在的目录下，运行”ls -l > index.txt&#8221;命令，生成一个index文件，重新尝试，问题解决。

同时，OpenBSD的各个镜像站点也都有相应的index文件，你可以选择从网上下载。