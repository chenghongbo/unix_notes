---
title: 十个减少个人信息泄露风险的建议
author: acheng
layout: post
date: 2013-03-16
excerpt: |
  看了昨天的3.15晚会，才知道利用浏览器cookie获取用户隐私居然成了一门生意 - 这个创新能力可是相当强！！
  
  面对这种情形，作为普通用户我们该怎么办？戒了互联网？因噎废食，显然是反应过度了。作为一个IT行业的从业者，以及安全问题的关注者，我提供一些建议，来减少网络浏览中被追踪的风险，供大家参考。
  
  1.  不要随便在什么网站上都注册。只在你信任或者一定要使用的网站上注册。
  
  2. 注册时尽量不要留下私人信息，尤其是手机号和身份证号码
url: /blog/stop-stealing-my-cookies/
categories:
  - 其它
  - 网络安全
---
看了昨天的3.15晚会，才知道利用浏览器cookie获取用户隐私居然成了一门生意 &#8211; 这个创新能力可是相当强！！

面对这种情形，作为普通用户我们该怎么办？戒了互联网？因噎废食，显然是反应过度了。作为一个IT行业的从业者，以及安全问题的关注者，我提供一些建议，来减少网络浏览中被追踪的风险，供大家参考。

[unordered_list style=&#8221;green-dot&#8221;]

  * 1.  不要随便在什么网站上都注册。只在你信任或者一定要使用的网站上注册。
  * 2. 注册时尽量不要留下私人信息，**尤其是手机号和身份证号码**
  * ****3. 如果可能，使用代理服务器进行网络浏览，避免你的地里位置被追踪；如果使用手机上网，关闭GPS
  * 4. 设置自己的浏览器，让网站设置cookie时进行提示，自己可以选择接受或者不接受此网站设置cookie  [注1]
  * 5. 如果可能，尽量不浏览、使用国内的网站以及软件。这不是说国外的网站、软件就不存在类似的问题，只是中枪的几率少一点，对隐私的尊重会多一点（由于目前技术的限制，cookie的使用不可避免，否则用户验证以及网络购物的功能会受到影响）。
  * 6. 可以设置Flash播放器不存储flashcookie [注2]；（注意：如果有些网站就是专门想要获取你的隐私，只要你输入了任何信息，他们不需要在本地存储也照样能够获取；但是如果你存储了这些信息，它们还有被其他的恶意网站或程序获取的风险。）
  * 7.  使用虚拟机，在你的电脑上再安装一个操作系统；需要进行网上购物或者电子银行等敏感业务时就在这个虚拟机中进行；完成后就关闭它，不要使用这个虚拟机进行任何其它网络活动。或者把敏感业务在你的笔记本/台式机上完成，平时的网络浏览和娱乐在虚拟机中进行。或者再创建几个虚拟机。
  * 8. 学习使用Linux，BSD或其它非Windows操作系统；获取对自己的电脑、系统或浏览器的更多控制。
  * 9. 尽量不使用手机上网，购物
  * 10. 理解下面这个现实：就目前的情况而言，只要上网，尤其是用手机上网，你的个人信息就有被人收集的可能

[/unordered_list]

[注1]  
首先，IE9和Firefox19 （其它版本没试）都提供隐私浏览模式（IE9称为InPrivate浏览），尽量使用这种模式浏览。

对于IE9浏览器，可以通过“Internet选项”对IE如何处理cookie进行设置，如下：

[<img class="alignleft size-full wp-image-1887" alt="ie-cookie-settings" src="http://www.kdump.cn/wp-content/uploads/2013/03/ie-cookie-settings.png" width="858" height="510" />][1]

<p style="text-align: left;">
  对Firefox浏览器，我没有找到类似的设置，只有下面这个：
</p>

<p style="text-align: left;">
  <a href="http://www.kdump.cn/wp-content/uploads/2013/03/firefox-cookie-settings.png"><img class="alignleft  wp-image-1888" alt="firefox-cookie-settings" src="http://www.kdump.cn/wp-content/uploads/2013/03/firefox-cookie-settings.png" width="606" height="325" /></a>
</p>

[注2]： 可以通过控制面板对Flash播放器如何处理flashcookie进行设置：

<p style="text-align: left;">
  <a href="http://www.kdump.cn/wp-content/uploads/2013/03/flash_cookie_settings.png"><img class="alignleft size-full wp-image-1889" alt="flash_cookie_settings" src="http://www.kdump.cn/wp-content/uploads/2013/03/flash_cookie_settings.png" width="940" height="546" /></a>
</p>

 [1]: http://www.kdump.cn/wp-content/uploads/2013/03/ie-cookie-settings.png