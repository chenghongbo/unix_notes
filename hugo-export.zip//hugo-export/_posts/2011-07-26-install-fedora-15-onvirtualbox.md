---
title: VirtualBox虚拟机中安装Fedora 15
author: acheng
layout: post
date: 2011-07-26
url: /blog/install-fedora-15-onvirtualbox/
categories:
  - Linux
  - 系统管理
tags:
  - fedora
  - gnome 3
  - linux
---
Fedora 15中默认使用了Gnome 3桌面环境。由于它类似于Apple的风格，相信吸引了不少用户。于是我也决定现在虚拟机中装一个Fedora 15，体验一下，如果真的很方便的话，可以考虑给在家庭电脑上使用，就不必过于担忧病毒/恶意软件之类的东东了。

GNOME 3图片：

[<img class="alignleft size-full wp-image-1196" title="search" src="http://www.kdump.cn/wp-content/uploads/2011/07/search.png" alt="" width="340" height="213" />][1]

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

关于如何安装，有需要的朋友可以参考下面这个链接：

<a href="http://www.sysprobs.com/install-fedora-15-virtualbox-steps-install-virtualbox-guest-additions-fedora-15" target="_blank">Install Fedora 15 on VirtualBox and Steps to Install VirtualBox Guest Additions on Fedora 15</a>

 [1]: http://www.kdump.cn/wp-content/uploads/2011/07/search.png