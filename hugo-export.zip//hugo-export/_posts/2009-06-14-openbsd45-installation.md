---
title: openbsd 4.5 安装
author: acheng
layout: post
date: 2009-06-14
excerpt: |
  这个视频演示OpenBSD4.5的安装，第一部分。演示使用的是VMware虚拟机。<br />可能有些朋友对OpenBSD还不是很了解,可以到这个<a href="http://www.9971.us/OpenBSD4.5/c/faq1.html#WhatIs">链接</a>来看一下。
  <embed src='http://player.youku.com/player.php/sid/XMTA0MjcxNDE2/v.swf' quality='high' width='680' height='480' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash'></embed>
url: /blog/openbsd45-installation/
categories:
  - 视频
tags:
  - samplevideo
  - sysadmin
---
这个视频演示OpenBSD4.5的安装，第一部分。演示使用的是VMware虚拟机。  
可能有些朋友对OpenBSD还不是很了解,可以到这个[链接][1]来看一下。  


<embed src='http://player.youku.com/player.php/sid/XMTA0MjcxNDE2/v.swf' quality='high' width='480' height='400' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash'>
</embed>

 [1]: http://www.9971.us/OpenBSD4.5/c/faq1.html#WhatIs