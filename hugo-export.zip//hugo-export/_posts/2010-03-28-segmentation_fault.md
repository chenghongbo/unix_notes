---
title: Apache segmentation fault
author: acheng
layout: post
date: 2010-03-28
excerpt: |
  |
    安装了phpldapadmin后，apache报出了很多seg fault的错误，虽然程序磕磕绊绊的还能运行。
    
    [acheng@henan ~]$ sudo tail -f /var/www/logs/error_log                                       
    [Sun Mar 28 21:15:12 2010] [notice] child pid 4112 exit signal Segmentation fault (11)
    [Sun Mar 28 21:15:16 2010] [notice] child pid 7268 exit signal Segmentation fault (11)
    [Sun Mar 28 21:15:50 2010] [notice] child pid 5508 exit signal Segmentation fault (11)
    [Sun Mar 28 21:15:55 2010] [notice] child pid 12292 exit signal Segmentation fault (11)
    [Sun Mar 28 21:15:59 2010] [notice] child pid 3828 exit signal Segmentation fault (11)
url: /blog/segmentation_fault/
categories:
  - blog
  - openbsd
  - 开源应用
tags:
  - news
---
安装了phpldapadmin后，apache报出了很多seg fault的错误，虽然程序磕磕绊绊的还能运行。

[acheng@henan ~]$ sudo tail -f /var/www/logs/error_log  
\[Sun Mar 28 21:15:12 2010\] \[notice\] child pid 4112 exit signal Segmentation fault (11)  
\[Sun Mar 28 21:15:16 2010\] \[notice\] child pid 7268 exit signal Segmentation fault (11)  
\[Sun Mar 28 21:15:50 2010\] \[notice\] child pid 5508 exit signal Segmentation fault (11)  
\[Sun Mar 28 21:15:55 2010\] \[notice\] child pid 12292 exit signal Segmentation fault (11)  
\[Sun Mar 28 21:15:59 2010\] \[notice\] child pid 3828 exit signal Segmentation fault (11)  
\[Sun Mar 28 21:16:02 2010\] \[notice\] child pid 4280 exit signal Segmentation fault (11)  
\[Sun Mar 28 21:16:02 2010\] \[notice\] child pid 12184 exit signal Segmentation fault (11)  
\[Sun Mar 28 21:16:07 2010\] \[notice\] child pid 10531 exit signal Segmentation fault (11)  
\[Sun Mar 28 21:16:07 2010\] \[notice\] child pid 18344 exit signal Segmentation fault (11)  
\[Sun Mar 28 21:16:16 2010\] \[notice\] child pid 17243 exit signal Segmentation fault (11)

估计估计是PHP和apache1.3之间的兼容性问题。有时间要trace一下。

问题搞定，还是suhosin补丁的问题。在php.ini中加入

suhosin.session.encrypt = off

即可。