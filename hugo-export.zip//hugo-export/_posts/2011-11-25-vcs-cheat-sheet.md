---
title: VCS cheat sheet
author: acheng
layout: post
date: 2011-11-25
url: /blog/vcs-cheat-sheet/
categories:
  - blog
  - 系统管理
---
http://www.datadisk.co.uk/html\_docs/veritas/veritas\_cluster_cs.htm

VCS uses two components, LLT and GAB to share data over the private networks among systems.

These components provide the performance and reliability required by VCS.

<table width="600" border="1">
  <tr>
    <td width="220">
      LLT
    </td>
    
    <td class="code_text" width="564">
      LLT (Low Latency Transport) provides fast, kernel-to-kernel comms and monitors network connections. The system admin configures the LLT by creating a configuration file (llttab) that describes the systems in the cluster and private network links among them. The LLT runs in layer 2 of the network stack
    </td>
  </tr>
  
  <tr>
    <td width="220">
      GAB
    </td>
    
    <td class="code_text" width="564">
      GAB (Group membership and Atomic Broadcast) provides the global message order required to maintain a synchronised state among the systems, and monitors disk comms such as that required by the VCS heartbeat utility. The system admin configures GAB driver by creating a configuration file ( gabtab).
    </td>
  </tr>
</table>

**LLT and GAB files**

<table border="1">
  <tr>
    <td valign="top" width="220">
      /etc/llthosts
    </td>
    
    <td class="code_text" valign="top" width="564">
      The file is a database, containing one entry per system, that links the LLT system ID with the hosts name. The file is identical on each server in the cluster.
    </td>
  </tr>
  
  <tr>
    <td valign="top" width="220">
      /etc/llttab
    </td>
    
    <td class="code_text" valign="top" width="564">
      The file contains information that is derived during installation and is used by the utility lltconfig.
    </td>
  </tr>
  
  <tr>
    <td valign="top" width="220">
      /etc/gabtab
    </td>
    
    <td class="code_text" valign="top" width="564">
      The file contains the information needed to configure the GAB driver. This file is used by the gabconfig utility.
    </td>
  </tr>
  
  <tr>
    <td valign="top" width="220">
      /etc/VRTSvcs/conf/config/main.cf
    </td>
    
    <td class="code_text" valign="top" width="564">
      The VCS configuration file. The file contains the information that defines the cluster and its systems.
    </td>
  </tr>
</table>

** Gabtab**** Entries**

<table border="1">
  <tr>
    <td valign="top" width="790">
      <p class="code_text">
        /sbin/gabdiskconf &#8211; i /dev/dsk/c1t2d0s2 -s 16 -S 1123
      </p>
      
      <p>
        /sbin/gabdiskconf &#8211; i /dev/dsk/c1t2d0s2 -s 144 -S 1124
      </p>
      
      <p>
        /sbin/gabdiskhb -a /dev/dsk/c1t2d0s2 -s 16 -p a -s 1123
      </p>
      
      <p>
        /sbin/gabdiskhb -a /dev/dsk/c1t2d0s2 -s 144 -p h -s 1124
      </p>
      
      <p>
        /sbin/gabconfig -c -n2</td> </tr> </tbody> </table> 
        
        <p>
          &nbsp;
        </p>
        
        <table width="800" border="1">
          <tr>
            <td width="146">
              <div align="left">
                gabdiskconf
              </div>
            </td>
            
            <td class="code_text" width="638">
              -i   Initialises the disk region-s   Start Block</p> 
              
              <p>
                -S   Signature</td> </tr> 
                
                <tr>
                  <td>
                    <div align="left">
                      gabdiskhb (heartbeat disks)
                    </div>
                  </td>
                  
                  <td class="code_text">
                    -a   Add a gab disk heartbeat resource-s   Start Block</p> 
                    
                    <p>
                      -p   Port
                    </p>
                    
                    <p>
                      -S   Signature</td> </tr> 
                      
                      <tr>
                        <td>
                          <div align="left">
                            gabconfig
                          </div>
                        </td>
                        
                        <td class="code_text">
                          -c   Configure the driver for use-n   Number of systems in the cluster.
                        </td>
                      </tr></tbody> </table> 
                      
                      <p>
                        <strong> LLT and GAB Commands<a name="lltandgab"></a></strong>
                      </p>
                      
                      <table width="800" border="1">
                        <tr>
                          <td width="293">
                            Verifying that links are active for LLT
                          </td>
                          
                          <td class="code_text" width="491">
                            lltstat -n
                          </td>
                        </tr>
                        
                        <tr>
                          <td width="293">
                            verbose output of the lltstat command
                          </td>
                          
                          <td class="code_text" width="491">
                            lltstat -nvv | more
                          </td>
                        </tr>
                        
                        <tr>
                          <td width="293">
                            open ports for LLT
                          </td>
                          
                          <td class="code_text" width="491">
                            lltstat -p
                          </td>
                        </tr>
                        
                        <tr>
                          <td>
                            display the values of LLT configuration directives
                          </td>
                          
                          <td class="code_text">
                            lltstat -c
                          </td>
                        </tr>
                        
                        <tr>
                          <td>
                            lists information about each configured LLT link
                          </td>
                          
                          <td class="code_text">
                            lltstat -l
                          </td>
                        </tr>
                        
                        <tr>
                          <td>
                            List all MAC addresses in the cluster
                          </td>
                          
                          <td class="code_text">
                            lltconfig -a list
                          </td>
                        </tr>
                        
                        <tr>
                          <td width="293">
                            stop the LLT running
                          </td>
                          
                          <td class="code_text" width="491">
                            lltconfig -U
                          </td>
                        </tr>
                        
                        <tr>
                          <td>
                            start the LLT
                          </td>
                          
                          <td class="code_text">
                            lltconfig -c
                          </td>
                        </tr>
                        
                        <tr>
                          <td width="293">
                            verify that GAB is operating
                          </td>
                          
                          <td class="code_text" width="491">
                            gabconfig -aNote: port a indicates that GAB is communicating, port h indicates that VCS is started
                          </td>
                        </tr>
                        
                        <tr>
                          <td>
                            stop GAB running
                          </td>
                          
                          <td class="code_text">
                            gabconfig -U
                          </td>
                        </tr>
                        
                        <tr>
                          <td>
                            start the GAB
                          </td>
                          
                          <td class="code_text">
                            gabconfig -c -n <number of nodes>
                          </td>
                        </tr>
                        
                        <tr>
                          <td width="293">
                            override the seed values in the gabtab file
                          </td>
                          
                          <td class="code_text" width="491">
                            gabconfig -c -x
                          </td>
                        </tr>
                      </table>
                      
                      <p>
                        <strong>GAB Port Memberbership<a name="port"></a></strong>
                      </p>
                      
                      <table width="800" border="1">
                        <tr>
                          <td width="294">
                            List Membership
                          </td>
                          
                          <td class="code_text" width="490">
                            gabconfig -a
                          </td>
                        </tr>
                        
                        <tr>
                          <td>
                            Unregister port f
                          </td>
                          
                          <td class="code_text">
                            /opt/VRTS/bin/fsclustadm cfsdeinit
                          </td>
                        </tr>
                        
                        <tr>
                          <td>
                            Port Function
                          </td>
                          
                          <td class="code_text">
                            a   gab driverb   I/O fencing (designed to guarantee data integrity)</p> 
                            
                            <p>
                              d   ODM (Oracle Disk Manager)
                            </p>
                            
                            <p>
                              f   CFS (Cluster File System)
                            </p>
                            
                            <p>
                              h   VCS (VERITAS Cluster Server: high availability daemon)<br /> o   VCSMM driver (kernel module needed for Oracle and VCS interface)
                            </p>
                            
                            <p>
                              q   QuickLog daemon
                            </p>
                            
                            <p>
                              v   CVM (Cluster Volume Manager)
                            </p>
                            
                            <p>
                              w   vxconfigd (module for cvm)</td> </tr> </tbody> </table> 
                              
                              <p>
                                <strong>Cluster daemons<a name="daemons"></a></strong>
                              </p>
                              
                              <table width="800" border="1">
                                <tr>
                                  <td width="295">
                                    High Availability Daemon
                                  </td>
                                  
                                  <td class="code_text" width="489">
                                    had
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    Companion Daemon
                                  </td>
                                  
                                  <td class="code_text" width="489">
                                    hashadow
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    Resource Agent daemon
                                  </td>
                                  
                                  <td class="code_text" width="489">
                                    <resource>Agent
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    Web Console cluster managerment daemon
                                  </td>
                                  
                                  <td class="code_text" width="489">
                                    CmdServer
                                  </td>
                                </tr>
                              </table>
                              
                              <p>
                                <strong>Cluster Log Files<a name="logs"></a></strong>
                              </p>
                              
                              <table width="800" border="1">
                                <tr>
                                  <td>
                                    Log Directory
                                  </td>
                                  
                                  <td class="code_text">
                                    /var/VRTSvcs/log
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="294">
                                    primary log file (engine log file)
                                  </td>
                                  
                                  <td class="code_text" width="490">
                                    /var/VRTSvcs/log/engine_A.log
                                  </td>
                                </tr>
                              </table>
                              
                              <p>
                                <strong>Starting and Stopping the cluster <a name="StartStop"></a></strong>
                              </p>
                              
                              <table width="800" border="1">
                                <tr>
                                  <td width="459">
                                    &#8220;-stale&#8221; instructs the engine to treat the local config as stale&#8221;-force&#8221; instructs the engine to treat a stale config as a valid one
                                  </td>
                                  
                                  <td class="code_text" width="325">
                                    hastart [-stale|-force]
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    Bring the cluster into running mode from a stale state using the configuration file from a particular server
                                  </td>
                                  
                                  <td class="code_text">
                                    hasys -force <server_name>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    stop the cluster on the local server but leave the application/s running, do not failover the application/s
                                  </td>
                                  
                                  <td class="code_text">
                                    hastop -local
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    stop cluster on local server but evacuate (failover) the application/s to another node within the cluster
                                  </td>
                                  
                                  <td class="code_text">
                                    hastop -local -evacuate
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    stop the cluster on all nodes but leave the application/s running
                                  </td>
                                  
                                  <td class="code_text">
                                    hastop -all -force
                                  </td>
                                </tr>
                              </table>
                              
                              <p>
                                <strong>Cluster Status<a name="ClusterStatus"></a></strong>
                              </p>
                              
                              <table width="800" border="1">
                                <tr>
                                  <td width="293">
                                    display cluster summary
                                  </td>
                                  
                                  <td class="code_text" width="491">
                                    hastatus -summary
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    continually monitor cluster
                                  </td>
                                  
                                  <td class="code_text">
                                    hastatus
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="293">
                                    verify the cluster is operating
                                  </td>
                                  
                                  <td class="code_text" width="491">
                                    hasys -display
                                  </td>
                                </tr>
                              </table>
                              
                              <p>
                                <strong>Cluster Details <a name="clusters"></a></strong>
                              </p>
                              
                              <table width="800" border="1">
                                <tr>
                                  <td width="293">
                                    information about a cluster
                                  </td>
                                  
                                  <td class="code_text" width="491">
                                    haclus -display
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="293">
                                    value for a specific cluster attribute
                                  </td>
                                  
                                  <td class="code_text" width="491">
                                    haclus -value <attribute>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="293">
                                    modify a cluster attribute
                                  </td>
                                  
                                  <td class="code_text" width="491">
                                    haclus -modify <attribute name> <new>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="293">
                                    Enable LinkMonitoring
                                  </td>
                                  
                                  <td class="code_text" width="491">
                                    haclus -enable LinkMonitoring
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="293">
                                    Disable LinkMonitoring
                                  </td>
                                  
                                  <td class="code_text" width="491">
                                    haclus -disable LinkMonitoring
                                  </td>
                                </tr>
                              </table>
                              
                              <p>
                                <strong>Users<a name="users"></a></strong>
                              </p>
                              
                              <table width="800" border="1">
                                <tr>
                                  <td width="292">
                                    add a user
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hauser -add <username>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    modify a user
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hauser -update <username>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    delete a user
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hauser -delete <username>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    display all users
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hauser -display
                                  </td>
                                </tr>
                              </table>
                              
                              <p>
                                <strong>System Operations<a name="SystemOperations"></a></strong>
                              </p>
                              
                              <table width="800" border="1">
                                <tr>
                                  <td>
                                    add a system to the cluster
                                  </td>
                                  
                                  <td class="code_text">
                                    hasys -add <sys>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    delete a system from the cluster
                                  </td>
                                  
                                  <td class="code_text">
                                    hasys -delete <sys>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    Modify a system attributes
                                  </td>
                                  
                                  <td class="code_text">
                                    hasys -modify <sys> <modify options>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    list a system state
                                  </td>
                                  
                                  <td class="code_text">
                                    hasys -state
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    Force a system to start
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hasys -force
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    Display the systems attributes
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hasys -display [-sys]
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    List all the systems in the cluster
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hasys -list
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    Change the load attribute of a system
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hasys -load <system> <value>
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    Display the value of a systems nodeid (/etc/llthosts)
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hasys -nodeid
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    Freeze a system (No offlining system, No groups onlining)
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hasys -freeze [-persistent][-evacuate]Note: main.cf must be in write mode
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td width="292">
                                    Unfreeze a system ( reenable groups and resource back online)
                                  </td>
                                  
                                  <td class="code_text" width="492">
                                    hasys -unfreeze [-persistent]Note: main.cf must be in write mode
                                  </td>
                                </tr>
                              </table>
                              
                              <p>
                                <strong> Dynamic Configuration<a name="dr"></a></strong><strong> </strong>
                              </p>
                              
                              <p>
                                The VCS configuration must be in read/write mode in order to make changes. When in read/write mode the
                              </p>
                              
                              <p>
                                configuration becomes stale, a .stale file is created in $VCS_CONF/conf/config. When the configuration is put
                              </p>
                              
                              <p>
                                back into read only mode the .stale file is removed.
                              </p>
                              
                              <table width="800" border="1">
                                <tr>
                                  <td width="245">
                                    Change configuration to read/write mode
                                  </td>
                                  
                                  <td class="code_text" width="539">
                                    haconf -makerw
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    Change configuration to read-only mode
                                  </td>
                                  
                                  <td class="code_text">
                                    haconf -dump -makero
                                  </td>
                                </tr>
                                
                                <tr>
                                  <td>
                                    Check what mode cluster is running in
                                  </td>
                                  
                                  <td class="code_text">
                                    haclus -display |grep -i &#8216;readonly&#8217;0 = write mode</p> 
                                    
                                    <p>
                                      1 = read only mode</td> </tr> 
                                      
                                      <tr>
                                        <td>
                                          Check the configuration file
                                        </td>
                                        
                                        <td class="code_text">
                                          hacf -verify /etc/VRTS/conf/configNote: you can point to any directory as long as it has main.cf and types.cf
                                        </td>
                                      </tr>
                                      
                                      <tr>
                                        <td>
                                          convert a main.cf file into cluster commands
                                        </td>
                                        
                                        <td class="code_text">
                                          hacf -cftocmd /etc/VRTS/conf/config -dest /tmp
                                        </td>
                                      </tr>
                                      
                                      <tr>
                                        <td width="245">
                                          convert a command file into a main.cf file
                                        </td>
                                        
                                        <td class="code_text" width="539">
                                          hacf -cmdtocf /tmp -dest /etc/VRTS/conf/config
                                        </td>
                                      </tr></tbody> </table> 
                                      
                                      <p>
                                        <strong>Service Groups<a name="ServiceGroups"></a> </strong>
                                      </p>
                                      
                                      <table width="800" border="1">
                                        <tr>
                                          <td>
                                            add a service group
                                          </td>
                                          
                                          <td class="code_text">
                                            haconf -makerwhagrp -add groupw<br /> hagrp -modify groupw SystemList sun1 1 sun2 2hagrp -autoenable groupw -sys sun1</p> 
                                            
                                            <p>
                                              haconf -dump -makero</td> </tr> 
                                              
                                              <tr>
                                                <td>
                                                  delete a service group
                                                </td>
                                                
                                                <td class="code_text">
                                                  haconf -makerwhagrp -delete groupw<br /> haconf -dump -makero
                                                </td>
                                              </tr>
                                              
                                              <tr>
                                                <td>
                                                  change a service group
                                                </td>
                                                
                                                <td class="code_text">
                                                  haconf -makerwhagrp -modify groupw SystemList sun1 1 sun2 2 sun3 3</p> 
                                                  
                                                  <p>
                                                    haconf -dump -makero
                                                  </p>
                                                  
                                                  <p>
                                                    Note: use the &#8220;hagrp -display <group>&#8221; to list attributes</td> </tr> 
                                                    
                                                    <tr>
                                                      <td width="290">
                                                        list the service groups
                                                      </td>
                                                      
                                                      <td class="code_text" width="494">
                                                        hagrp -list
                                                      </td>
                                                    </tr>
                                                    
                                                    <tr>
                                                      <td width="290">
                                                        list the groups dependencies
                                                      </td>
                                                      
                                                      <td class="code_text" width="494">
                                                        hagrp -dep <group>
                                                      </td>
                                                    </tr>
                                                    
                                                    <tr>
                                                      <td width="290">
                                                        list the parameters of a group
                                                      </td>
                                                      
                                                      <td class="code_text" width="494">
                                                        hagrp -display <group>
                                                      </td>
                                                    </tr>
                                                    
                                                    <tr>
                                                      <td width="290">
                                                        display a service group&#8217;s resource
                                                      </td>
                                                      
                                                      <td class="code_text" width="494">
                                                        hagrp -resources <group>
                                                      </td>
                                                    </tr>
                                                    
                                                    <tr>
                                                      <td width="290">
                                                        display the current state of the service group
                                                      </td>
                                                      
                                                      <td class="code_text" width="494">
                                                        hagrp -state <group>
                                                      </td>
                                                    </tr>
                                                    
                                                    <tr>
                                                      <td width="290">
                                                        clear a faulted non-persistent resource in a specific grp
                                                      </td>
                                                      
                                                      <td class="code_text" width="494">
                                                        hagrp -clear <group> [-sys] <host> <sys>
                                                      </td>
                                                    </tr>
                                                    
                                                    <tr>
                                                      <td>
                                                        Change the system list in a cluster
                                                      </td>
                                                      
                                                      <td class="code_text">
                                                        # remove the hosthagrp -modify grp_zlnrssd SystemList -delete <hostname></p> 
                                                        
                                                        <p>
                                                          # add the new host (don&#8217;t forget to state its position)
                                                        </p>
                                                        
                                                        <p>
                                                          hagrp -modify grp_zlnrssd SystemList -add <hostname> 1
                                                        </p>
                                                        
                                                        <p>
                                                          # update the autostart list
                                                        </p>
                                                        
                                                        <p>
                                                          hagrp -modify grp_zlnrssd AutoStartList <host> <host></td> </tr> </tbody> </table> 
                                                          
                                                          <p>
                                                            <strong>Service Group Operations<a name="ServiceGroup"></a></strong>
                                                          </p>
                                                          
                                                          <table width="800" border="1">
                                                            <tr>
                                                              <td width="292">
                                                                Start a service group and bring its resources online
                                                              </td>
                                                              
                                                              <td class="code_text" width="492">
                                                                hagrp -online <group> -sys <sys>
                                                              </td>
                                                            </tr>
                                                            
                                                            <tr>
                                                              <td width="292">
                                                                Stop a service group and takes its resources offline
                                                              </td>
                                                              
                                                              <td class="code_text" width="492">
                                                                hagrp -offline <group> -sys <sys>
                                                              </td>
                                                            </tr>
                                                            
                                                            <tr>
                                                              <td width="292">
                                                                Switch a service group from system to another
                                                              </td>
                                                              
                                                              <td class="code_text" width="492">
                                                                hagrp -switch <group> to <sys>
                                                              </td>
                                                            </tr>
                                                            
                                                            <tr>
                                                              <td>
                                                                Enable all the resources in a group
                                                              </td>
                                                              
                                                              <td class="code_text">
                                                                hagrp -enableresources <group>
                                                              </td>
                                                            </tr>
                                                            
                                                            <tr>
                                                              <td>
                                                                Disable all the resources in a group
                                                              </td>
                                                              
                                                              <td class="code_text">
                                                                hagrp -disableresources <group>
                                                              </td>
                                                            </tr>
                                                            
                                                            <tr>
                                                              <td width="292">
                                                                Freeze a service group (disable onlining and offlining)
                                                              </td>
                                                              
                                                              <td class="code_text" width="492">
                                                                hagrp -freeze <group> [-persistent]note: use the following to check &#8220;hagrp -display <group> | grep TFrozen&#8221;
                                                              </td>
                                                            </tr>
                                                            
                                                            <tr>
                                                              <td width="292">
                                                                Unfreeze a service group (enable onlining and offlining)
                                                              </td>
                                                              
                                                              <td class="code_text" width="492">
                                                                hagrp -unfreeze <group> [-persistent]note: use the following to check &#8220;hagrp -display <group> | grep TFrozen&#8221;
                                                              </td>
                                                            </tr>
                                                            
                                                            <tr>
                                                              <td width="292">
                                                                Enable a service group. Enabled groups can only be brought online
                                                              </td>
                                                              
                                                              <td class="code_text" width="492">
                                                                haconf -makerwhagrp -enable <group> [-sys]</p> 
                                                                
                                                                <p>
                                                                  haconf -dump -makero
                                                                </p>
                                                                
                                                                <p>
                                                                  Note to check run the following command &#8220;hagrp -display | grep Enabled&#8221;</td> </tr> 
                                                                  
                                                                  <tr>
                                                                    <td width="292">
                                                                      Disable a service group. Stop from bringing online
                                                                    </td>
                                                                    
                                                                    <td class="code_text" width="492">
                                                                      haconf -makerwhagrp -disable <group> [-sys]</p> 
                                                                      
                                                                      <p>
                                                                        haconf -dump -makero
                                                                      </p>
                                                                      
                                                                      <p>
                                                                        Note to check run the following command &#8220;hagrp -display | grep Enabled&#8221;</td> </tr> 
                                                                        
                                                                        <tr>
                                                                          <td width="292">
                                                                            Flush a service group and enable corrective action.
                                                                          </td>
                                                                          
                                                                          <td class="code_text" width="492">
                                                                            hagrp -flush <group> -sys <system>
                                                                          </td>
                                                                        </tr></tbody> </table> 
                                                                        
                                                                        <p>
                                                                          <strong>Resources<a name="resources"></a></strong>
                                                                        </p>
                                                                        
                                                                        <table width="800" border="1">
                                                                          <tr>
                                                                            <td>
                                                                              add a resource
                                                                            </td>
                                                                            
                                                                            <td class="code_text">
                                                                              haconf -makerwhares -add appDG DiskGroup groupw</p> 
                                                                              
                                                                              <p>
                                                                                hares -modify appDG Enabled 1
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                hares -modify appDG DiskGroup appdg
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                hares -modify appDG StartVolumes 0<br /> haconf -dump -makero</td> </tr> 
                                                                                
                                                                                <tr>
                                                                                  <td>
                                                                                    delete a resource
                                                                                  </td>
                                                                                  
                                                                                  <td class="code_text">
                                                                                    haconf -makerwhares -delete <resource></p> 
                                                                                    
                                                                                    <p>
                                                                                      haconf -dump -makero</td> </tr> 
                                                                                      
                                                                                      <tr>
                                                                                        <td>
                                                                                          change a resource
                                                                                        </td>
                                                                                        
                                                                                        <td class="code_text">
                                                                                          haconf -makerwhares -modify appDG Enabled 1</p> 
                                                                                          
                                                                                          <p>
                                                                                            haconf -dump -makero
                                                                                          </p>
                                                                                          
                                                                                          <p>
                                                                                            Note: list parameters &#8220;hares -display <resource>&#8221;</td> </tr> 
                                                                                            
                                                                                            <tr>
                                                                                              <td>
                                                                                                change a resource attribute to be globally wide
                                                                                              </td>
                                                                                              
                                                                                              <td class="code_text">
                                                                                                hares -global <resource> <attribute> <value>
                                                                                              </td>
                                                                                            </tr>
                                                                                            
                                                                                            <tr>
                                                                                              <td>
                                                                                                change a resource attribute to be locally wide
                                                                                              </td>
                                                                                              
                                                                                              <td class="code_text">
                                                                                                hares -local <resource> <attribute> <value>
                                                                                              </td>
                                                                                            </tr>
                                                                                            
                                                                                            <tr>
                                                                                              <td>
                                                                                                list the parameters of a resource
                                                                                              </td>
                                                                                              
                                                                                              <td class="code_text">
                                                                                                hares -display <resource>
                                                                                              </td>
                                                                                            </tr>
                                                                                            
                                                                                            <tr>
                                                                                              <td width="245">
                                                                                                list the resources
                                                                                              </td>
                                                                                              
                                                                                              <td class="code_text" width="539">
                                                                                                hares -list
                                                                                              </td>
                                                                                            </tr>
                                                                                            
                                                                                            <tr>
                                                                                              <td width="245">
                                                                                                list the resource dependencies
                                                                                              </td>
                                                                                              
                                                                                              <td class="code_text" width="539">
                                                                                                hares -dep
                                                                                              </td>
                                                                                            </tr></tbody> </table> 
                                                                                            
                                                                                            <p>
                                                                                              <strong>Resource Operations<a name="ResourceOperations"></a></strong>
                                                                                            </p>
                                                                                            
                                                                                            <table width="800" border="1">
                                                                                              <tr>
                                                                                                <td width="293">
                                                                                                  Online a resource
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="491">
                                                                                                  hares -online <resource> [-sys]
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td width="293">
                                                                                                  Offline a resource
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="491">
                                                                                                  hares -offline <resource> [-sys]
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  display the state of a resource( offline, online, etc)
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  hares -state
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  display the parameters of a resource
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  hares -display <resource>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td width="293">
                                                                                                  Offline a resource and propagate the command to its children
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="491">
                                                                                                  hares -offprop <resource> -sys <sys>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td width="293">
                                                                                                  Cause a resource agent to immediately monitor the resource
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="491">
                                                                                                  hares -probe <resource> -sys <sys>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td width="293">
                                                                                                  Clearing a resource (automatically initiates the onlining)
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="491">
                                                                                                  hares -clear <resource> [-sys]
                                                                                                </td>
                                                                                              </tr>
                                                                                            </table>
                                                                                            
                                                                                            <p>
                                                                                              <strong>Resource Types</strong>
                                                                                            </p>
                                                                                            
                                                                                            <table width="800" border="1">
                                                                                              <tr>
                                                                                                <td width="294">
                                                                                                  Add a resource type
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="490">
                                                                                                  hatype -add <type>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  Remove a resource type
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  hatype -delete <type>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  List all resource types
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  hatype -list
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  Display a resource type
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  hatype -display <type>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  List a partitcular resource type
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  hatype -resources <type>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  Change a particular resource types attributes
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  hatype -value <type> <attr>
                                                                                                </td>
                                                                                              </tr>
                                                                                            </table>
                                                                                            
                                                                                            <p>
                                                                                              <strong>Resource Agents<a id="ResourceAgents" name="ResourceAgents"></a> </strong>
                                                                                            </p>
                                                                                            
                                                                                            <table width="800" border="1">
                                                                                              <tr>
                                                                                                <td>
                                                                                                  add a agent
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  pkgadd -d . <agent package>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  remove a agent
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  pkgrm <agent package>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  change a agent
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  n/a
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td width="293">
                                                                                                  list all ha agents
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="491">
                                                                                                  haagent -list
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td width="293">
                                                                                                  Display agents run-time information i.e has it started, is it running ?
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="491">
                                                                                                  haagent -display <agent_name>
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td>
                                                                                                  Display agents faults
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text">
                                                                                                  haagent -display |grep Faults
                                                                                                </td>
                                                                                              </tr>
                                                                                            </table>
                                                                                            
                                                                                            <p>
                                                                                              <strong>Resource Agent Operations<a name="AgentOperations"></a></strong>
                                                                                            </p>
                                                                                            
                                                                                            <table width="800" border="1">
                                                                                              <tr>
                                                                                                <td width="292">
                                                                                                  Start an agent
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="492">
                                                                                                  haagent -start <agent_name>[-sys]
                                                                                                </td>
                                                                                              </tr>
                                                                                              
                                                                                              <tr>
                                                                                                <td width="292">
                                                                                                  Stop an agent
                                                                                                </td>
                                                                                                
                                                                                                <td class="code_text" width="492">
                                                                                                  haagent -stop <agent_name>[-sys]
                                                                                                </td>
                                                                                              </tr>
                                                                                            </table>