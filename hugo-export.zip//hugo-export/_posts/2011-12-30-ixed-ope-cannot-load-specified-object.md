---
title: 'ixed.5.2.ope:  Cannot load specified object'
author: acheng
layout: post
date: 2011-12-30
url: /blog/ixed-ope-cannot-load-specified-object/
categories:
  - openbsd
  - 开源应用
---
在OpenBSD上安装[VIMP][1]的时候sourceguardian 的loader报错：

\# ./symfony framework:init mysql://user:pwd@127.0.0.1/db  
Failed loading /usr/local/lib/php-5.2/modules/ixed.5.2.ope:  Cannot load specified object  
为啥不能加载呢？

根据这个[链接][2]，打开PHP的debug看看：

\# LD_DEBUG=1 php -m 2>&1 | grep fail  
dlopen: failed to open libc.so.50.1  
dlopen: /usr/local/lib/php-5.2/modules/ixed.5.2.ope: done (failed).  
#

原来是无法找到libc.so.50.1

系统上的libc呢？

\# ls /usr/lib/libc.so*  
/usr/lib/libc.so.60.1

这样做个软连接就可以了：

ln -fs /usr/lib/libc.so.60.1 /usr/lib/libc.so.50.1

 [1]: http://www.vimp.com
 [2]: http://blog.endpoint.com/2011/02/debugging-php-extensions-with-dynamic.html