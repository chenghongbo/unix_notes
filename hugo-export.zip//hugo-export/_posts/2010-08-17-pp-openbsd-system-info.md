---
title: OpenBSD预备课程 – 获取系统信息
author: acheng
layout: post
date: 2010-08-17
excerpt: 要确保系统运行正常，或者在排错时，都需要查看一下系统信息，确定系统的运行状态。这个视频讲述如何获取系统的一些常见信息，比如系统的负载状况，有哪些进程，磁盘空间的使用情况等等。
url: /blog/pp-openbsd-system-info/
categories:
  - 视频
tags:
  - samplevideo
---
要确保系统运行正常，或者在排错时，都需要查看一下系统信息，确定系统的运行状态。这个视频讲述如何获取系统的一些常见信息，比如系统的负载状况，有哪些进程，磁盘空间的使用情况等等。

<div id="jw_wrap_1282054867023">
</div>