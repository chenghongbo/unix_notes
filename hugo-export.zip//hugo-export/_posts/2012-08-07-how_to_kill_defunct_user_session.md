---
title: 如何断开无效的用户登录会话
author: acheng
layout: post
date: 2012-08-07
url: /blog/how_to_kill_defunct_user_session/
categories:
  - blog
  - openbsd
  - 系统管理
tags:
  - openbsd
---
昨天发现OpenBSD系统上有一个登录的会话，已经空闲了9天。想必是哪天在手机上测试SSH端口转发后造成的。

<div class="sb_info">
  #w<br /> 6:07PM up 12 days, 21:42, 2 users, load averages: 0.24, 0.14, 0.09<br /> USER TTY FROM LOGIN@ IDLE WHAT<br /> acheng p0 180.116.63.38 6:00PM 0 w<br /> acheng p4 114.227.123.110 27Jul12 9days -
</div>

该如何把它解决掉呢？查了一下，ttyp4上已经没有什么进程了，想用kill也没机会了。

<div class="sb_info">
  #ps -t p4<br /> PID TT STAT TIME COMMAND
</div>

正常情况下，即使用户会话断开，也会有一些进程在运行，我们可以通过上面这个命令找到这些进程，然后使用kill命令把它们干掉。于是我发邮件到[misc@ 请教][1]。经指点后发现，这是因为那个会话的SSHD没有正常退出，导致了utmp文件中相应的记录没有被清理，从而出现了w命令报告有用户登录会话，但却没有任何进程的情况出现。系统重启后这个不是问题的问题就会自动消失。

同时，推荐阅读utmp的用户手册来了解更多。

<div class="sb_note">
  man utmp<br /> &#8230;.<br /> After the new lastlog record is written, the utmp file is opened and the<br /> utmp record for the user is inserted. This record remains until the user<br /> logs out at which time it is deleted. The utmp file is used by the<br /> programs rwho(1), users(1), w(1), and who(1)&#8230;.
</div>

 [1]: http://marc.info/?l=openbsd-misc&m=134422222525207&w=2