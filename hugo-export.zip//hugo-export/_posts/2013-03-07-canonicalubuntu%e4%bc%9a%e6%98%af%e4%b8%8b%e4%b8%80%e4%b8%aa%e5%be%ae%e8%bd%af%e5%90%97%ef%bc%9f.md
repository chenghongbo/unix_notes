---
title: Canonical/Ubuntu会是下一个微软吗？
author: acheng
layout: post
date: 2013-03-07
excerpt: |
  今天看到消息，Canonical准备开发一个自己的X窗口系统 - Mir，从而给Ubuntu用户一个更好，更一致的使用体验，不管是在笔记本，平板，手机还是电视上。而它的Unity Next桌面系统也将完全基于Mir。
  
  根据Mir的维基页面，Canonical认为随着新设备新技术的出现，用户对显示效果和使用体验的要求也越来越高，而目前的X窗口系统已不再能满足用户的期望。
url: /blog/canonicalubuntu%e4%bc%9a%e6%98%af%e4%b8%8b%e4%b8%80%e4%b8%aa%e5%be%ae%e8%bd%af%e5%90%97%ef%bc%9f/
categories:
  - Linux
  - news
tags:
  - linux
  - ubuntu
---
今天看到消息，Canonical准备开发一个自己的X窗口系统 &#8211; Mir，从而给Ubuntu用户一个更好，更一致的使用体验，不管是在笔记本，平板，手机还是电视上。而它的Unity Next桌面系统也将完全基于Mir。

根据Mir的维基页面，Canonical认为随着新设备新技术的出现，用户对显示效果和使用体验的要求也越来越高，而目前的X窗口系统已不再能满足用户的期望。而Canonical的业务也从传统的PC/服务器扩展到平板/手机/电视领域，X窗口系统无法满足在所有这些设备上的现实要求。

Ubuntu可以说是目前在Linux桌面系统上做得不错的一个发行版；而随着云计算的兴起，它在服务器市场的份额也在不断增加，今年初更是宣布进军移动领域。看来Canonical志向不小。

Read more about Mir on <a href="https://wiki.ubuntu.com/MirSpec" target="_blank">https://wiki.ubuntu.com/MirSpec</a>