---
title: faac and the malformated aac bit stream error
author: acheng
layout: post
date: 2011-11-29
url: /blog/faac-and-the-malformated-aac-bit-stream-error/
categories:
  - openbsd
  - 开源应用
  - 系统管理
---
在OpenBSD上编译了ffmpeg后，VIMP在转码的时候无法将mp4文件转换为m4v格式。手工执行同样的命令出现类似下面的错误：

malformated aac bit stream , use -absf aac_adtstoasc

av\_interleaved\_write_frame(): Operation not permitted

&nbsp;

折腾了半天才发现，可能是OpenBSD 5.0的faac-2.18p2软件包的问题，将它卸载后重新编译faac软件后转码成功。

至此，VIMP2.2可以在OpenBSD 上运行了。

<http://kdump.no-ip.org/>