---
title: OpenBSD进程的开机启动-续
author: acheng
layout: post
date: 2012-08-09
url: /blog/start_daemon_on_boot_openbsd_2/
categories:
  - blog
  - openbsd
  - 系统管理
---
[前面][1]我们谈到如何开机启动系统自带的进程，今天谈一下如何开机启动用户自己安装的守护进程。

对于用户自己安装的守护进程，一般pkg_add命令结束后会给出相应的提示。以mysql服务器来说，它会提示启动脚本已经安装在/etc/rc.d目录下了。对于这样的进程，开机启动的设置也很简单。只需在/etc/rc.conf.local文件下添加一行:

<div class="sb_info">
  pkg_scripts=&#8221;mysqld&#8221;
</div>

如果需要启动多个自己安装的守护进程，一次添加到mysqld前面或后面即可。如：

<div class="sb_info">
  pkg_scripts=&#8221;mysqld squid postfix&#8221;
</div>

如果这多个进程之间有依赖关系，需要注意他们的顺序。开机时，系统按照他们出现的顺序依次启动（从前往后），关机时按照相反的顺序（从后往前）一次关闭。因此需要先启动（同时后关闭）的就要放在前面，否则就放在后面。

 [1]: http://www.kdump.cn/content/start_daemon_on_boot_openbsd