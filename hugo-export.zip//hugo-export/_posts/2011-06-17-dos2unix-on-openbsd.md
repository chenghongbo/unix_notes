---
title: DOS2UNIX on OpenBSD
author: acheng
layout: post
date: 2011-06-17
url: /blog/dos2unix-on-openbsd/
categories:
  - openbsd
  - 系统管理
tags:
  - unix2dos
---
OpenBSD上没有DOS2UNIX命令的， 那么我们如何删除某些来自Windows的文件中那些讨厌的^M符号呢？

答案是：使用tr命令。

tr -d &#8216; 15&#8242; < win.file > unix.file

其中win.file就是中间含有^M符号的文件，unix.file就是去除^M后生成的新文件。