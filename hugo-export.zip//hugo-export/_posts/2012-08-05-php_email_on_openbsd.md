---
title: OpenBSD上的PHP邮件发送问题
author: acheng
layout: post
date: 2012-08-05
url: /blog/php_email_on_openbsd/
categories:
  - blog
  - openbsd
  - 系统管理
---
OpenBSD上的自带的Apache由于chroot的缘故，会导致PHP的mail函数失效，而且PHP也不会返回错误。很难排错。

下面是解决这个问题的一个大致的流程，供在OpenBSD上遇到邮件问题的用户参考：

1. 首先确保在命令行下直接用mail命令发送邮件没有问题。如果命令行下都无法发送邮件，说明MTA有问题，解决了这个问题以后来解决 CHROOT APACHE + PHP的问题。

2. 在/var/www/目录下创建etc目录，并将/etc/resolv.conf文件复制到其下

3. 在/var/www/目录下创建bin目录，并将/bin/ksh和/bin/sh复制到其下

4. 安装femail-chroot （如果你不知道如何在OpenBSD上安装软件，google一下pkg_add openbsd)

5. 修改php配置文件（在OpenBSD 5.1 + php-5.3.10的情况下，php 配置文件为/etc/php-5.3.ini），在[mail  function]一节下，修改sendmail_path参数如下

<div class="custom_attn_box" style="width: 540px; border-bottom: 3px solid #629DE3;border-top: 3px solid #629DE3;color: #05B; background: no-repeat scroll 10px 50% #D8E5F8; text-align: left;">
  <p>
    [mail function]<br /> &#8230;
  </p>
  
  <p>
    ; For Unix only. You may supply arguments as well (default: &#8220;sendmail -t -i&#8221;).<br /> ; http://php.net/sendmail-path<br /> <strong>sendmail_path = /bin/femail -t -i</strong> </div> 
    
    <p>
      6. 重启APACHE，测试邮件发送是否已经OK
    </p>