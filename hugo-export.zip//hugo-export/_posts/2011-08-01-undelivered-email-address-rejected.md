---
title: Undelivered – 5.1.0 Address rejected
author: acheng
layout: post
date: 2011-08-01
url: /blog/undelivered-email-address-rejected/
categories:
  - blog
  - 系统管理
---
<pre>最近在做一个&lt;a href="http://zh.wikipedia.org/wiki/DKIM"&gt;DKIM&lt;/a&gt;相关的项目。有用户的邮件无法接收。OUTLOOK返回如下错误信息：

This message was created automatically by the mail system.

A message that you sent could not be delivered to one or more of its recipients. This is a permanent error. 
The following address(es) failed:

&gt;&gt;&gt; jar@example.com (Undelivered): 550 #5.1.0 Address rejected 
&gt;&gt;&gt; jar@example.com

查询了一下，发现错误代码 5.1.0表示Exchange服务器无法在目录找到相应邮件地址，因此拒绝递送相关邮件，这个错误和DKIM本身没有任何关系。

详情请参阅微软相关文档：

http://support.microsoft.com/kb/284204</pre>