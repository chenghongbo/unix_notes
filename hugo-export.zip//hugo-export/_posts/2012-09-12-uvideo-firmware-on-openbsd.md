---
title: uvideo-firmware on OpenBSD
author: acheng
layout: post
date: 2012-09-12
url: /blog/uvideo-firmware-on-openbsd/
categories:
  - openbsd
---
uvideo-firmware是OpenBSD上一些USB摄像头的驱动程序，由于许可权的问题，它们不能包含在OpenBSD的安装光盘里。

当安装系统时，安装程序如果检测到有相匹配的摄像头，那么系统第一次启动时就会尝试到firmware.openbsd.org上去下载相应的驱动。如果这个时候计算机无法连接到互联网，驱动安装就会失败，以后也不会再自动尝试。

今天在一台ThinkPad X120E机器上安装OpenBSD 5.2 snapshot （2012-09-11）就碰到了这种情况。由于OpenBSD未能成功驱动x120e的无线网卡，机器无法访问互联网。

这个时候需要自己修复网络访问的问题。然后手工下载固件进行安装。http://firmware.openbsd.org/firmware/uvideo-firmware-1.2p0.tgz

目前尚未确认此驱动是否能成功驱动自带的摄像头。