---
title: Fcitx on OpenBSD + Gnome
author: acheng
layout: post
date: 2011-08-17
url: /blog/fcitx-on-openbsd-gnome/
categories:
  - openbsd
  - 视频
tags:
  - fcitx
---
