---
title: 初识DragonFlyBSD的软件管理系统
author: acheng
layout: post
date: 2012-08-11
url: /blog/package_management_on_dragonflybsd/
categories:
  - DragonFlyBSD
  - 系统管理
tags:
  - DragonFlyBSD
---
偶然间又看到DragonFlyBSD的消息，一时兴起，想要测试一下这个系统，看一下它的Hammer FS。于是就在虚拟机里安装了DragonFlyBSD3.0.2。

<div class="sb_note">
  初步印象（和OpenBSD的使用体验相比较）：
</div>

如果你的英文没有问题的话，按照安装盘的提示一步一步来，安装比较简单。

小于10G的磁盘默认不使用Hammer FS。

安装完成后直接在控制台以root登录，无须密码；

而默认的SSH验证也只接受密钥方式，所以需要创建一个用户，然后创建密钥，设置改用户的密钥验证，然后才能使用ssh远程登录。否则只能在控制台登录。

添加用户的时候发现useradd命令默认没有，需要使用adduser，以互动方式添加。

<div class="sb_note">
  软件管理：
</div>

系统装完后就要安装软件，不然系统也没什么用处。简单说，DragonFlyBSD的软件在管理方式上和其他的BSD也没有太大的区别。

阅读了官方的pkgsrc文档之后，将常见的软件安装，删除及搜索等的方式汇总如下：

<div class="sb_info">
  1. 准备工作<br /> 系统装完后运行如下命令（以root用户）：</p> 
  
  <p>
    # cd /usr<br /> # rm -rf pkgsrc<br /> # make pkgsrc-create<br /> # make pkgsrc-update
  </p>
</div>

<div class="sb_tip">
  2. 软件搜索：<br /> # pkg_search $pkg_name （搜索已经编译好的软件包）</p> 
  
  <p>
    或者<br /> # cd /usr/pkgsrc/<br /> # bmake search key=&#8217;$pkg_name&#8217;
  </p>
</div>

<div class="sb_info">
  3. 安装编译好的软件：<br /> # pkg_radd -v $pkg_name
</div>

<div class="sb_tip">
  4. 使用pkgsrc来编译安装软件（借用官方文档的例子）<br /> # cd /usr/pkgsrc/misc/screen （切换到软件screen所在位置<br /> # bmake install clean （编译安装）</p> 
  
  <p>
    如果想要查看编译选项：<br /> # bmake show-options
  </p>
  
  <p>
    使用特定选项进行编译(本人没有使用/验证）：<br /> # bmake PKG_OPTIONS.$pkg_name=&#8221;-option1 option2&#8243; install clean
  </p>
  
  <p>
    下面的命令优先安装编译好的二进制文件，没有编译好的文件时再使用源文件编译安装：<br /> # bmake bin-install clean
  </p>
</div>

<div class="sb_info">
  5. 列出所有已安装的软件：<br /> # pkg_info
</div>

<div class="sb_tip">
  6. 删除软件：<br /> # pkg_delete $pkg_name</p> 
  
  <p>
    或者，对于使用bmake安装的软件，使用<br /> # bmake deinstall （应该需要先切换到软件在/usr/pkgsrc下的目录，没试过）
  </p>
</div>

了解了软件管理的基本知识，下面一篇，我们要在系统上安装所谓的DAMP（Apache/MySQ/PHP）。