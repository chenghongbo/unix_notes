---
title: OpenBSD上支持HOSTAP模式的无线网卡
author: acheng
layout: post
date: 2012-09-28
url: /blog/openbsd%e4%b8%8a%e6%94%af%e6%8c%81hostap%e6%a8%a1%e5%bc%8f%e7%9a%84%e6%97%a0%e7%ba%bf%e7%bd%91%e5%8d%a1/
categories:
  - openbsd
  - 系统管理
---
最近想要用闲置的逸珑上网本做一个无线AP，代替无线路由器。但是阴差阳错，买来的TP-LINK TL-WN821N USB无线网卡在OpenBSD下不支持HOSTAP模式，因此我把OpenBSD手册中列出的支持HOSTAP模式的无线网卡收集上来，供自己和大家参考。

注意：  
1. 收集的时间是2012-09-28. 这个列表会随着时间的流逝而逐渐失去其参考价值，后来者留意！  
2. 查找最新的列表，请至http://www.openbsd.org/i386.html#hardware， Wireless Ethernet Adapters一节，点开网卡驱动名称的链接，其中会列出此驱动是否支持HOSTAP模式，以及此驱动适用于哪些网卡产品。  
3. 列表中仅列出支持HOSTAP模式的网卡，未列出的网卡未必就不支持HOSTAP模式，需进一步确认  
4. 目前OpenBSD所有驱动均不支持802.11N模式  
5. 有些网卡型号相同，但版本号不同，使用的芯片组也不同。不常见，但是一定要当心！

OK，支持HOSTAP模式的无线网卡是：&#8230;&#8230;.

<div>
       ath &#8211; Atheros IEEE 802.11a/b/g wireless network device with GPIO
</div>

<div>
       The following cards are among those supported by the ath driver:
</div>

<div>
</div>

<div>
             Card                   Chip      Bus         Standard
</div>

<div>
             3Com 3CRPAG175         AR5212    CardBus     a/b/g
</div>

<div>
             Cisco AIR-CB21AG       AR5212    CardBus     a/b/g
</div>

<div>
             D-Link DWL-A650        AR5210    CardBus     a
</div>

<div>
             D-Link DWL-AB650       AR5211    CardBus     a/b
</div>

<div>
             D-Link DWL-A520        AR5210    PCI         a
</div>

<div>
             Elecom LD-WL54         AR5211    CardBus     a
</div>

<div>
             IBM 11ABG WL LAN       AR5212    Mini PCI    a/b/g
</div>

<div>
             Linksys WPC51AB        AR5211    CardBus     a/b
</div>

<div>
             Netgear WAB501         AR5211    CardBus     a/b
</div>

<div>
             Planet WL-3560         AR5211    CardBus     a/b/g
</div>

<div>
             Proxim Skyline 4030    AR5210    CardBus     a
</div>

<div>
             Proxim Skyline 4032    AR5210    PCI         a
</div>

<div>
             Senao NL-5354MP        AR5212    Mini PCI    a/b/g
</div>

<div>
             SMC SMC2735W           AR5210    CardBus     a
</div>

<div>
             Sony PCWA-C500         AR5210    CardBus     a
</div>

<div>
             Wistron CM9            AR5212    Mini PCI    a/b/g
</div>

<div>
  ==================================================================================
</div>

<div>
       athn &#8211; Atheros IEEE 802.11a/g/n wireless network device
</div>

<div>
</div>

<div>
       The athn driver provides support for a wide variety of Atheros 802.11n
</div>

<div>
       devices, ranging from the AR5008 up to the AR9287.
</div>

<div>
</div>

<div>
       The following table summarizes the supported chips and their
</div>

<div>
       capabilities.
</div>

<div>
</div>

<div>
             Chipset                        Spectrum     TxR:S    Bus
</div>

<div>
             AR5008-2NG (AR5416+AR2122)     2GHz         2&#215;2:2    PCI/CardBus
</div>

<div>
             AR5008-3NG (AR5416+AR2133)     2GHz         3&#215;3:2    PCI/CardBus
</div>

<div>
             AR5008-2NX (AR5416+AR5122)     2GHz/5GHz    2&#215;2:2    PCI/CardBus
</div>

<div>
             AR5008-3NX (AR5416+AR5133)     2GHz/5GHz    3&#215;3:2    PCI/CardBus
</div>

<div>
             AR5008E-2NG (AR5418+AR2122)    2GHz         2&#215;2:2    PCIe
</div>

<div>
             AR5008E-3NG (AR5418+AR2133)    2GHz         3&#215;3:2    PCIe
</div>

<div>
             AR5008E-2NX (AR5418+AR5122)    2GHz/5GHz    2&#215;2:2    PCIe
</div>

<div>
             AR5008E-3NX (AR5418+AR5133)    2GHz/5GHz    3&#215;3:2    PCIe
</div>

<div>
             AR9001-2NG (AR9160+AR9103)     2GHz         2&#215;2:2    PCI
</div>

<div>
             AR9001-3NG (AR9160+AR9103)     2GHz         3&#215;3:2    PCI
</div>

<div>
             AR9001-3NX2 (AR9160+AR9106)    2GHz/5GHz    3&#215;3:2    PCI
</div>

<div>
             AR9220                         2GHz/5GHz    2&#215;2:2    PCI
</div>

<div>
             AR9223                         2GHz         2&#215;2:2    PCI
</div>

<div>
             AR9280                         2GHz/5GHz    2&#215;2:2    PCIe
</div>

<div>
             AR9280+AR7010                  2GHz/5GHz    2&#215;2:2    USB 2.0
</div>

<div>
             AR9281                         2GHz         1&#215;2:2    PCIe
</div>

<div>
             AR9285                         2GHz         1&#215;1:1    PCIe
</div>

<div>
             AR9271                         2GHz         1&#215;1:1    USB 2.0
</div>

<div>
             AR2427                         2GHz         1&#215;1:1    PCIe
</div>

<div>
             AR9227                         2GHz         2&#215;2:2    PCI
</div>

<div>
             AR9287                         2GHz         2&#215;2:2    PCIe
</div>

<div>
             AR9287+AR7010                  2GHz         2&#215;2:2    USB 2.0
</div>

<div>
  ==================================================================================
</div>

<div>
       pgt &#8211; Conexant/Intersil Prism GT Full-MAC IEEE 802.11a/b/g wireless
</div>

<div>
       network device
</div>

<div>
       The following cards are among those supported by the pgt driver:
</div>

<div>
</div>

<div>
             Card                                      Chip       Bus
</div>

<div>
             3COM 3CRWE154G72                          ISL3880    CardBus
</div>

<div>
             D-Link DWL-g650 A1                        ISL3890    PCI
</div>

<div>
             I-O Data WN-G54/CB                        ISL3890    PCI
</div>

<div>
             I4 Z-Com XG-600                           ISL3890    PCI
</div>

<div>
             I4 Z-Com XG-900                           ISL3890    PCI
</div>

<div>
             Intersil PRISM Indigo                     ISL3877    PCI
</div>

<div>
             Intersil PRISM Duette                     ISL3890    PCI
</div>

<div>
             NETGEAR WG511 (Taiwanese, not Chinese)    ISL3890    CardBus
</div>

<div>
             PLANEX GW-DS54G                           ISL3890    PCI
</div>

<div>
             SMC EZ Connect g 2.4GHz SMC2802W          ISL3890    PCI
</div>

<div>
             SMC EZ Connect g 2.4GHz SMC2835W-v2       ISL3890    CardBus
</div>

<div>
             SMC 2802Wv2                               ISL3890    PCI
</div>

<div>
             Soyo Aerielink                            ISL3890    CardBus
</div>

<div>
             ZyXEL ZyAIR G-100                         ISL3890    CardBus
</div>

<div>
  ==================================================================================
</div>

<div>
       rtw &#8211; Realtek RTL8180L IEEE 802.11b wireless network device
</div>

<div>
</div>

<div>
             Card                              Radio      Bus
</div>

<div>
             Allnet ALL0182                    SA2400     CardBus
</div>

<div>
             Belkin F5D6020 V3                 SA2400     CardBus
</div>

<div>
             Buffalo WLI-CB-B11                SA2400     CardBus
</div>

<div>
             Corega CG-WLCB11V3                SA2400     CardBus
</div>

<div>
             D-Link DWL-610                    ?          CardBus
</div>

<div>
             Edimax EW-7106                    SA2400     CardBus
</div>

<div>
             GigaFast WF721-AEX (R* serial)    GRF5101    CardBus
</div>

<div>
             Jensen AirLink 6011               GRF5101    CardBus
</div>

<div>
             Level-One WPC-0101                SA2400     CardBus
</div>

<div>
             Linksys WPC11 v4                  MAX2820    CardBus
</div>

<div>
             Netgear MA521                     SA2400     CardBus
</div>

<div>
             Ovislink AirLive WL-1120PCM       SA2400     CardBus
</div>

<div>
             Planet WL-3553                    SA2400     CardBus
</div>

<div>
             Q-Tec 770WC                       SA2400     CardBus
</div>

<div>
             Q-Tec 775WC                       SA2400     CardBus
</div>

<div>
             Roper FreeLan 802.11b             SA2400     CardBus
</div>

<div>
             SAFECOM SWLCR-1100                SA2400     CardBus
</div>

<div>
             TRENDnet TEW-226PC                ?          CardBus
</div>

<div>
             VCTnet PC-11B1                    SA2400     CardBus
</div>

<div>
             Winstron CB-200B                  SA2400     CardBus
</div>

<div>
             Zonet ZEW1000                     GRF5101    CardBus
</div>

<div>
  ==================================================================================
</div>

<div>
       acx &#8211; TI ACX100/ACX111 IEEE 802.11a/b/g wireless network device
</div>

<div>
       The following cards are among those supported by the acx driver:
</div>

<div>
</div>

<div>
             Card                   Chip      Bus        Standard
</div>

<div>
             D-Link DWL-520+        ACX100    PCI        b
</div>

<div>
             D-Link DWL-650+        ACX100    CardBus    b
</div>

<div>
             D-Link DWL-G520+       ACX111    PCI        b/g
</div>

<div>
             D-Link DWL-G630+       ACX111    CardBus    b/g
</div>

<div>
             D-Link DWL-G650+       ACX111    CardBus    b/g
</div>

<div>
             Digitus DN-7001G       ACX111    CardBus    b/g
</div>

<div>
             Ergenic ERG WL-003     ACX100    CardBus    b
</div>

<div>
             Hamlet HNWP254         ACX111    CardBus    b/g
</div>

<div>
             Hawking HWP54G         ACX111    PCI        b/g
</div>

<div>
             Linksys WPC54Gv2       ACX111    CardBus    b/g
</div>

<div>
             Microcom Travelcard    ACX111    CardBus    b/g
</div>

<div>
             Netgear WG311v2        ACX111    PCI        b/g
</div>

<div>
             Sceptre SC254W+        ACX111    CardBus    b/g
</div>

<div>
             Tornado/ADT 211g       ACX111    PCI        b/g
</div>

<div>
             USR USR5410            ACX111    CardBus    b/g
</div>

<div>
             USR USR5416            ACX111    PCI        b/g
</div>

<div>
             ZyXEL G-160            ACX111    CardBus    b/g
</div>

<div>
             ZyXEL G-360 EE         ACX111    PCI        b/g
</div>

<div>
</div>

<div>
  ==================================================================================
</div>

<div>
       wi &#8211; WaveLAN/IEEE, PRISM 2-3, and Spectrum24 IEEE 802.11b wireless
</div>

<div>
       network device
</div>

<div>
     The following cards are among those supported by the wi driver:
</div>

<div>
</div>

<div>
       Card                                 Chip         Bus
</div>

<div>
       &#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;-
</div>

<div>
       3Com AirConnect 3CRWE737A            Spectrum24   PCMCIA
</div>

<div>
       3Com AirConnect 3CRWE777A            Prism-2      PCI
</div>

<div>
       Acer Warplink USB-400                Prism-3      USB
</div>

<div>
       Actiontec HWC01170                   Prism-2.5    PCMCIA
</div>

<div>
       Actiontec HWU01170                   Prism-3      USB
</div>

<div>
       Adaptec AWN-8030                     Prism-2.5    PCMCIA
</div>

<div>
       Addtron AWA-100                      Prism-2      PCI
</div>

<div>
       Addtron AWP-100                      Prism-2      PCMCIA
</div>

<div>
       Agere ORiNOCO                        Hermes       PCMCIA
</div>

<div>
       AirVast WM168b                       Prism-3      USB
</div>

<div>
       AmbiCom WL1100C-CF                   Prism-3      CF
</div>

<div>
       Ambit WLAN                           Prism-3      USB
</div>

<div>
       Apacer Wireless Steno MB112          Prism-3      USB
</div>

<div>
       Apple Airport                        Hermes       macobio
</div>

<div>
       ARtem Onair                          Hermes       PCMCIA
</div>

<div>
       ASUS SpaceLink WL-100                Prism-2.5    PCMCIA
</div>

<div>
       ASUS SpaceLink WL-110                Prism-2.5    CF
</div>

<div>
       ASUS WL-140                          Prism-3      USB
</div>

<div>
       Belkin F5D6020 (version 1 only)      Prism-2      PCMCIA
</div>

<div>
       Belkin F5D6001 (version 1 only)      Prism-2      PCI
</div>

<div>
       Belkin F5D6060 (version 1 only)      Prism-2.5    CF
</div>

<div>
       Buffalo AirStation                   Prism-2      PCMCIA
</div>

<div>
       Buffalo AirStation                   Prism-2      CF
</div>

<div>
       Cabletron RoamAbout                  Hermes       PCMCIA
</div>

<div>
       Compaq Agency NC5004                 Prism-2      PCMCIA
</div>

<div>
       Compaq W100                          Prism-3      USB
</div>

<div>
       Contec FLEXLAN/FX-DS110-PCC          Prism-2      PCMCIA
</div>

<div>
       Corega PCC-11                        Prism-2      PCMCIA
</div>

<div>
       Corega PCCA-11                       Prism-2      PCMCIA
</div>

<div>
       Corega PCCB-11                       Prism-2      PCMCIA
</div>

<div>
       Corega CGWLPCIA11                    Prism-2      PCI
</div>

<div>
       Corega WLUSB-11                      Prism-3      USB
</div>

<div>
       Corega WLUSB-11 Key                  Prism-3      USB
</div>

<div>
       D-Link DCF-660W                      Prism-2      CF
</div>

<div>
       D-Link DWL-120 (rev F)               Prism-3      USB
</div>

<div>
       D-Link DWL-122                       Prism-3      USB
</div>

<div>
       D-Link DWL-520 (rev A and B only)    Prism-2.5    PCI
</div>

<div>
       D-Link DWL-650 (rev A1-J3 only)      Prism-2.5    PCMCIA
</div>

<div>
       ELSA XI300                           Prism-2      PCMCIA
</div>

<div>
       ELSA XI325                           Prism-2.5    PCMCIA
</div>

<div>
       ELSA XI325H                          Prism-2.5    PCMCIA
</div>

<div>
       ELSA XI800                           Prism-2      CF
</div>

<div>
       EMTAC A2424i                         Prism-2      PCMCIA
</div>

<div>
       Ericsson Wireless LAN CARD C11       Spectrum24   PCMCIA
</div>

<div>
       Gemtek WL-311                        Prism-2.5    PCMCIA
</div>

<div>
       Hawking Technology WE110P            Prism-2.5    PCMCIA
</div>

<div>
       I-O DATA WN-B11/PCM                  Prism-2      PCMCIA
</div>

<div>
       I-O DATA WN-B11/USB                  Prism-3      USB
</div>

<div>
       Intel PRO/Wireless 2011              Spectrum24   PCMCIA
</div>

<div>
       Intel PRO/Wireless 2011B             Prism-3      USB
</div>

<div>
       Intersil Prism II                    Prism-2      PCMCIA
</div>

<div>
       Intersil Mini PCI                    Prism-2.5    PCI
</div>

<div>
       Intersil ISL3872                     Prism-3      PCI
</div>

<div>
       Intersil Prism 2X                    Prism-3      USB
</div>

<div>
       JVC MP-XP7250                        Prism-3      USB
</div>

<div>
       Linksys WCF12                        Prism-3      CF
</div>

<div>
       Linksys Instant Wireless WPC11       Prism-2      PCMCIA
</div>

<div>
       Linksys Instant Wireless WPC11 2.5   Prism-2.5    PCMCIA
</div>

<div>
       Linksys Instant Wireless WPC11 3.0   Prism-3      PCMCIA
</div>

<div>
       Linksys WUSB11 v3.0                  Prism-3      USB
</div>

<div>
       Linksys WUSB12                       Prism-3      USB
</div>

<div>
       Longshine 8301                       Prism-2      PCI
</div>

<div>
       Lucent WaveLAN                       Hermes       PCMCIA
</div>

<div>
       Melco WLI-USB-KB11                   Prism-3      USB
</div>

<div>
       Melco WLI-USB-KS11G                  Prism-3      USB
</div>

<div>
       Melco WLI-USB-S11                    Prism-3      USB
</div>

<div>
       Microsoft MN510                      Prism-3      USB
</div>

<div>
       Microsoft MN520                      Prism-2.5    PCMCIA
</div>

<div>
       NANOSPEED ROOT-RZ2000                Prism-2      PCMCIA
</div>

<div>
       NDC/Sohoware NCP130                  Prism-2      PCI
</div>

<div>
       NEC CMZ-RT-WP                        Prism-2      PCMCIA
</div>

<div>
       Netgear MA111 (version 1 only)       Prism-3      USB
</div>

<div>
       Netgear MA311                        Prism-2.5    PCI
</div>

<div>
       Netgear MA401                        Prism-2      PCMCIA
</div>

<div>
       Netgear MA401RA                      Prism-2.5    PCMCIA
</div>

<div>
       Netgear MA701                        Prism-2.5    CF
</div>

<div>
       Nokia C020 Wireless LAN              Prism-I      PCMCIA
</div>

<div>
       Nokia C110/C111 Wireless LAN         Prism-2      PCMCIA
</div>

<div>
       Nortel E-mobility 211818-A           Spectrum24   PCI
</div>

<div>
       NTT-ME 11Mbps Wireless LAN           Prism-2      PCMCIA
</div>

<div>
       Pheenet WL-503IA                     Prism-3      USB
</div>

<div>
       Planex GW-NS11H                      Prism-3      PCMCIA
</div>

<div>
       Planex GW-US11H                      Prism-3      USB
</div>

<div>
       Pretec Compact WLAN OC-WLBXX-A       Prism-2.5    CF
</div>

<div>
       Proxim Harmony                       Prism-2      PCMCIA
</div>

<div>
       Proxim RangeLAN-DS                   Prism-2      PCMCIA
</div>

<div>
       Samsung MagicLAN SWL-2000N           Prism-2      PCMCIA
</div>

<div>
       Samsung MagicLAN SWL-2210P           Prism-2      PCI
</div>

<div>
       Senao NL-2511CF                      Prism-3      CF
</div>

<div>
       Senao NL-2511MP                      Prism-2.5    PCI
</div>

<div>
       Siemens SpeedStream SS1021           Prism-2      PCMCIA
</div>

<div>
       Siemens SpeedStream SS1022           Prism-3      USB
</div>

<div>
       Sitecom WL-022                       Prism-3      USB
</div>

<div>
       SMC 2632 EZ Connect                  Prism-2      PCMCIA
</div>

<div>
       Symbol Spectrum24                    Spectrum24   PCMCIA
</div>

<div>
       Symbol LA4123                        Spectrum24   PCI
</div>

<div>
       Syntax USB-400                       Prism-3      USB
</div>

<div>
       TDK LAK-CD011WL                      Prism-2      PCMCIA
</div>

<div>
       US Robotics 1120                     Prism-3      USB
</div>

<div>
       US Robotics 2410                     Prism-2      PCMCIA
</div>

<div>
       US Robotics 2445                     Prism-2      PCMCIA
</div>

<div>
       ViewSonic Airsync                    Prism-2.5    USB
</div>

<div>
       Z-Com XI-725/726                     Prism-2.5    USB
</div>

<div>
       Z-Com XI-735                         Prism-3      USB
</div>

<div>
       ZyXEL ZyAIR B-200                    Prism-3      USB
</div>

<div>
  ==================================================================================
</div>

<div>
       ral &#8211; Ralink Technology IEEE 802.11a/g/n wireless network device
</div>

<div>
</div>

<div>
       The following PCI adapters should work:
</div>

<div>
</div>

<div>
       A-Link WL54H.  AirLive WN-5000PCI.  Amigo AWI-926W.  AMIT WL531P.  AOpen
</div>

<div>
       AOI-831.  ASUS WL-130G.  ASUS WL-130N.  ASUS WIFI-G-AAY.  Atlantis Land
</div>

<div>
       A02-PCI-W54.  Belkin F5D7000 v3.  Canyon CN-WF511.  CNet CWP-854.  Compex
</div>

<div>
       WLP54G.  Conceptronic C54Ri.  Corega CG-WLPCI54GL.  Digitus DN-7006G-RA.
</div>

<div>
       Dynalink WLG25PCI.  E-Tech WGPI02.  Edimax EW-7128g.  Edimax EW-7628Ig.
</div>

<div>
       Edimax EW-7728In.  Eminent EM3037.  Encore ENLWI-G-RLAM.  Eusso
</div>

<div>
       UGL2454-VPR.  Fiberline WL-400P.  Foxconn WLL-3350.  Gigabyte GN-WPKG.
</div>

<div>
       Gigabyte GN-WP01GS.  Gigabyte GN-WI02GM.  Gigabyte GN-WP01GM.  Hawking
</div>

<div>
       HWP54GR.  Hercules HWGPCI-54.  iNexQ CR054g-009 (R03).  JAHT WN-4054PCI.
</div>

<div>
       KCORP LifeStyle KLS-660.  LevelOne WNC-0301 v2.  Linksys WMP54G v4.
</div>

<div>
       Longshine LCS-8031N.  Micronet SP906GK.  Minitar MN54GPC-R.  MSI MS-6834.
</div>

<div>
       MSI PC54G2.  OvisLink EVO-W54PCI.  PheeNet HWL-PCIG/RA.  Planex PCI-GW-
</div>

<div>
       DS300N.  Pro-Nets PC80211G.  Repotec RP-WP0854.  SATech SN-54P.  Signamax
</div>

<div>
       065-1798.  Sitecom WL-115.  SparkLAN WL-660R.  Surecom EP-9321-g.
</div>

<div>
       Surecom EP-9321-g1.  Sweex LC700030.  TekComm NE-9321-g.  Tonze PC-6200C.
</div>

<div>
       Unex CR054g-R02.  Zinwell ZWX-G361.  Zonet ZEW1600.
</div>

<div>
</div>

<div>
       The following CardBus adapters should work:
</div>

<div>
</div>

<div>
       A-Link WL54PC.  Alfa AWPC036.  Amigo AWI-914W.  AMIT WL531C.  ASUS
</div>

<div>
       WL-107G.  Atlantis Land A02-PCM-W54.  Belkin F5D7010 v2.  Canyon CN-
</div>

<div>
       WF513.  CC&C WL-2102.  CNet CWC-854.  Compex WL54.  Conceptronic C54RC.
</div>

<div>
       Corega CG-WLCB54GL.  Digiconnect WL591C.  Digitus DN-7001G-RA.  Dynalink
</div>

<div>
       WLG25CARDBUS.  E-Tech WGPC02.  E-Tech WGPC03.  Edimax EW-7108PCg.  Edimax
</div>

<div>
       EW-7708PN.  Eminent EM3036.  Encore ENPWI-G-RLAM.  Eusso UGL2454-01R.
</div>

<div>
       Fiberline WL-400X.  Gigabyte GN-WMKG.  Gigabyte GN-WM01GS.  Gigabyte GN-
</div>

<div>
       WM01GM.  Hawking HWC54GR.  Hercules HWGPCMCIA-54.  JAHT WN-4054P(E).
</div>

<div>
       KCORP LifeStyle KLS-611.  LevelOne WPC-0301 v2.  Micronet SP908GK V3.
</div>

<div>
       Minitar MN54GCB-R.  MSI CB54G2.  MSI MS-6835.  Pro-Nets CB80211G.
</div>

<div>
       Repotec RP-WB7108.  SATech SN-54C.  Sitecom WL-112.  SparkLAN WL-611R.
</div>

<div>
       SparkLAN WPCR-501.  Surecom EP-9428-g.  Sweex LC500050.  TekComm
</div>

<div>
       NE-9428-g.  Tonze PW-6200C.  Unex MR054g-R02.  Zinwell ZWX-G160.  Zonet
</div>

<div>
       ZEW1500.
</div>

<div>
</div>

<div>
       The following Mini PCI adapters should work:
</div>

<div>
</div>

<div>
       Amigo AWI-922W.  Billionton MIWLGRL.  Gigabyte GN-WIKG.  Gigabyte GN-
</div>

<div>
       WI01GS.  Gigabyte GN-WI02GM.  MSI MP54G2.  MSI MS-6833.  SparkLAN
</div>

<div>
       WMIR-215GN.  Tonze PC-620C.  Zinwell ZWX-G360.
</div>

<div>
</div>

<div>
  ==================================================================================
</div>

<div>
       ural &#8211; Ralink Technology USB IEEE 802.11b/g wireless network device
</div>

<div>
</div>

<div>
      The following adapters should work:
</div>

<div>
</div>

<div>
             AMIT WL532U
</div>

<div>
             ASUS WL-167g v1
</div>

<div>
             Belkin F5D7050 v2000
</div>

<div>
             Buffalo WLI-U2-KG54
</div>

<div>
             Buffalo WLI-U2-KG54-AI
</div>

<div>
             Buffalo WLI-U2-KG54-YB
</div>

<div>
             CNet CWD-854
</div>

<div>
             Compex WLU54G 2A1100
</div>

<div>
             Conceptronic C54RU
</div>

<div>
             D-Link DWL-G122 (b1)
</div>

<div>
             Dynalink WLG25USB
</div>

<div>
             E-Tech WGUS02
</div>

<div>
             Eminent EM3035
</div>

<div>
             Gigabyte GN-WBKG
</div>

<div>
             Hercules HWGUSB2-54
</div>

<div>
             KCORP LifeStyle KLS-685
</div>

<div>
             Linksys HU200-TS
</div>

<div>
             Linksys WUSB54G v4
</div>

<div>
             Linksys WUSB54GP v4
</div>

<div>
             MSI MS-6861
</div>

<div>
             MSI MS-6865
</div>

<div>
             MSI MS-6869
</div>

<div>
             Nintendo Wi-Fi USB Connector
</div>

<div>
             Nova Tech NV-902W
</div>

<div>
             OvisLink Evo-W54USB
</div>

<div>
             SerComm UB801R
</div>

<div>
             SparkLAN WL-685R
</div>

<div>
             Sphairon UB801R
</div>

<div>
             Surecom EP-9001-g rev 3A
</div>

<div>
             Sweex LC100060
</div>

<div>
             Tonze UW-6200C
</div>

<div>
             Zaapa ZNWUSB-54
</div>

<div>
             Zinwell ZPlus-G250
</div>

<div>
             Zinwell ZWX-G261
</div>

<div>
             Zonet ZEW2500P
</div>

<div>
  ==================================================================================
</div>

<div>
       rum &#8211; Ralink Technology USB IEEE 802.11a/b/g wireless network device
</div>

<div>
</div>

<div>
             3Com Aolynk WUB320g
</div>

<div>
             Abocom WUG2700
</div>

<div>
             Airlink101 AWLL5025
</div>

<div>
             ASUS WL-167g ver 2
</div>

<div>
             Atlantis Land A02-UP1-W54
</div>

<div>
             Belkin F5D7050 ver 3
</div>

<div>
             Belkin F5D9050 ver 3
</div>

<div>
             Belkin F5D9050C
</div>

<div>
             Buffalo WLI-U2-SG54HG
</div>

<div>
             Buffalo WLI-U2-SG54HP
</div>

<div>
             Buffalo WLI-U2-G54HP
</div>

<div>
             CNet CWD-854 ver F
</div>

<div>
             Conceptronic C54RU ver 2
</div>

<div>
             Corega CG-WLUSB2GL
</div>

<div>
             Corega CG-WLUSB2GO
</div>

<div>
             Corega CG-WLUSB2GPX
</div>

<div>
             D-Link DWA-110
</div>

<div>
             D-Link DWA-111
</div>

<div>
             D-Link DWL-G122 rev C1
</div>

<div>
             D-Link WUA-1340
</div>

<div>
             Digitus DN-7003GR
</div>

<div>
             Edimax EW-7318Ug
</div>

<div>
             Edimax EW-7318USg
</div>

<div>
             Edimax EW-7618Ug
</div>

<div>
             Gigabyte GN-WB01GS
</div>

<div>
             Gigabyte GN-WI05GS
</div>

<div>
             Hawking HWUG1
</div>

<div>
             Hawking HWU54DM
</div>

<div>
             Hercules HWGUSB2-54-LB
</div>

<div>
             Hercules HWGUSB2-54V2-AP
</div>

<div>
             LevelOne WNC-0301USB v3
</div>

<div>
             Linksys WUSB200
</div>

<div>
             Linksys WUSB54G rev C
</div>

<div>
             Linksys WUSB54GR
</div>

<div>
             Planex GW-US54HP
</div>

<div>
             Planex GW-US54Mini2
</div>

<div>
             Planex GW-USMM
</div>

<div>
             Senao NUB-3701
</div>

<div>
             Sitecom WL-113 ver 2
</div>

<div>
             Sitecom WL-172
</div>

<div>
             Sweex LW053
</div>

<div>
             TP-LINK TL-WN321G
</div>

<div>
</div>

<div>
</div>

<div>
</div>