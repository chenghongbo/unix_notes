---
title: OpenBSD5.0_Gnome2.3安装用ISO
author: acheng
layout: post
date: 2012-03-23
url: /blog/openbsd5_gnome2_install_iso/
categories:
  - blog
  - openbsd
---
上一篇文章中我简单介绍了一下[OpenBSD 5.0 + Gnome 2.3的一个VirtualBox虚拟机][1]文件。现在对应的一个可安装的ISO文件也基本可用了。可以在115网盘上下载。

part1： http://115.com/file/anznxk3c

part2：http://115.com/file/e7y7av8o

下载完成后，使用7-zip软件解压，然后会生成一个名为OpenBSD.iso的文件。

文件校验和：  
MD5 (OpenBSD.iso) = 1ee617cc03ba218e1e4308e2322f331f  
SHA1 (OpenBSD.iso) = ccd703f8301e9f712c1a7446e2d41f68ac443e5d

&nbsp;

**如何使用**

按上面的介绍，下载并解压出OpenBSD.iso文件后，即可像安装OpenBSD系统一样开始安装。（如果不熟悉OpenBSD安装，可参考[这个视频][2]）。

关键点有两个：

1. 保证/usr/local所在分区大于2.5G（因为Gnome桌面会安装较多软件）

2. 在选择安装组件时，要手工选择site50.tgz文件

这个ISO是OpenBSD5.0，I386平台。稍后我会录制一个演示视频。

&nbsp;

已知问题：

1. 如果使用root以外的账户登录，需要手工指定gnome主题为Equinox_Evolution，才能看到图示的效果。

可以在System > Preferences > Appearance菜单下选择”Equinox_Evolution“主题。

然后，在桌面上右击，选择”Change Desktop Background&#8221;, 指定/usr/local/share/backgrounds/puffy\_engraved\_2_1024x768.jpg图片做桌面背景

2. 第一次启动后会报类似下面的错误。这是个gnome-panel的问题。点击&#8221;don&#8217;t delete&#8221;.登录后再重启一遍可以解决这个问题。  
[<img src="http://farm8.staticflickr.com/7132/6853018266_5de89e0cd4_z.jpg" alt="notification_area" width="640" height="480" />][3]  
[<img src="http://farm8.staticflickr.com/7085/6999142793_4c0f044068_z.jpg" alt="clock_applet" width="640" height="480" />][4]

&nbsp;

ISO文件在VirtualBox和Vmware workstation虚拟机软件中测试通过。应该也可以用于物理机的安装，但是我没测试。

 [1]: http://www.kdump.cn/content/gnome_on_openbsd_virtualbox_image/
 [2]: http://www.kdump.org/video/Setting-up-OpenBSD-learning-env---part-3/8f66c71dfdb25c51b5c3075a02b46488
 [3]: http://www.flickr.com/photos/kdump/6853018266/ "Flickr 上 kdump 的 notification_area"
 [4]: http://www.flickr.com/photos/kdump/6999142793/ "Flickr 上 kdump 的 clock_applet"