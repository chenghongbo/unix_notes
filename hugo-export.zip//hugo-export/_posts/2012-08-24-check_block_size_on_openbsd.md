---
title: OpenBSD上查看文件系统的块大小
author: acheng
layout: post
date: 2012-08-24
url: /blog/check_block_size_on_openbsd/
categories:
  - openbsd
  - 系统管理
---
在OpenBSD上，使用disklabel $disk可以看到文件系统或者说分区的block size。  
下面的输出中，bsize一栏对应的就是该分区的block size。OpenBSD上默认是16KB (16384).

<div class="sb_tip">
  #disklabel sd0<br /> # /dev/rsd0c:<br /> type: SCSI<br /> disk: SCSI disk<br /> &#8230;&#8230;<br /> 16 partitions:<br /> <strong># size offset fstype [fsize bsize cpg]<br /> a: 19470688 64 4.2BSD 2048 16384 1 # /</strong><br /> b: 1494073 19470752 swap # none<br /> c: 20971520 0 unused
</div>