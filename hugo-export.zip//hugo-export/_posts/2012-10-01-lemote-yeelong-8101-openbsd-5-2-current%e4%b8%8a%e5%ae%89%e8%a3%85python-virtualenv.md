---
title: YeeLong 8101 + OpenBSD 5.2上安装Python Virtualenv
author: acheng
layout: post
date: 2012-09-30
excerpt: |
  最近准备将VIMP的一个视频平台网站迁移到一台龙芯机器上（运行OpenBSD 5.2-current mips64el），同时还可以将它作为家里的无线接入点。几经考量，准备使用MediaCore社区版。
  
  MediaCore是使用Python开发的一个视频网站平台
url: /blog/lemote-yeelong-8101-openbsd-5-2-current%e4%b8%8a%e5%ae%89%e8%a3%85python-virtualenv/
categories:
  - openbsd
tags:
  - MediaCore
  - Python
---
最近准备将VIMP的一个视频平台网站迁移到一台龙芯机器上（运行OpenBSD 5.2-current mips64el），同时还可以将它作为家里的无线接入点。几经考量，准备使用MediaCore社区版。

MediaCore是使用Python开发的一个视频网站平台。安装过程中有一步需要安装Python的Virtualenv。按照安装手册操作却行不通。

> YeeLong# easy_install virtualenv
> 
> Searching for virtualenv  
> Reading http://mediacorecommunity.org/dependencies/dev/
> 
> Link to http://pypi.python.org/simple/virtualenv/ \*\\*\*BLOCKED\*\** by &#8211;allow-hosts
> 
> Couldn&#8217;t find index page for &#8216;virtualenv&#8217; (maybe misspelled?)  
> Scanning index of all packages (this may take a while)
> 
> Link to http://pypi.python.org/simple/ \*\\*\*BLOCKED\*\** by &#8211;allow-hosts
> 
> No local packages or download links found for virtualenv  
> Best match: None  
> Traceback (most recent call last):  
> File &#8220;/usr/local/bin/easy_install&#8221;, line 8, in <module>  
> load\_entry\_point(&#8216;setuptools==0.6c11&#8242;, &#8216;console\_scripts&#8217;, &#8216;easy\_install&#8217;)()  
> File &#8220;/usr/local/lib/python2.7/site-packages/setuptools-0.6c11-py2.7.egg/setuptools/command/easy_install.py&#8221;, line 1712  
> , in main  
> File &#8220;/usr/local/lib/python2.7/site-packages/setuptools-0.6c11-py2.7.egg/setuptools/command/easy_install.py&#8221;, line 1700  
> , in with\_ei\_usage  
> File &#8220;/usr/local/lib/python2.7/site-packages/setuptools-0.6c11-py2.7.egg/setuptools/command/easy_install.py&#8221;, line 1716  
> , in <lambda>  
> File &#8220;/usr/local/lib/python2.7/distutils/core.py&#8221;, line 152, in setup  
> dist.run_commands()  
> File &#8220;/usr/local/lib/python2.7/distutils/dist.py&#8221;, line 953, in run_commands
> 
> File &#8220;/usr/local/lib/python2.7/distutils/dist.py&#8221;, line 972, in run_command  
> cmd_obj.run()  
> File &#8220;/usr/local/lib/python2.7/site-packages/setuptools-0.6c11-py2.7.egg/setuptools/command/easy_install.py&#8221;, line 211,  
> in run  
> File &#8220;/usr/local/lib/python2.7/site-packages/setuptools-0.6c11-py2.7.egg/setuptools/command/easy_install.py&#8221;, line 434,  
> in easy_install  
> File &#8220;/usr/local/lib/python2.7/site-packages/setuptools-0.6c11-py2.7.egg/setuptools/package_index.py&#8221;, line 475, in fet  
> ch_distribution  
> AttributeError: &#8216;NoneType&#8217; object has no attribute &#8216;clone&#8217;
> 
> &nbsp;
> 
> google后发现可以直接下载Virtualenv包的源码进行安装：
> 
> YeeLong# ftp http://pypi.python.org/packages/source/v/virtualenv/virtualenv-1.7.1.2.tar.gz
> 
> YeeLong# easy_install virtualenv-1.7.1.2.tar.gz  
> Processing virtualenv-1.7.1.2.tar.gz  
> Running virtualenv-1.7.1.2/setup.py -q bdist\_egg &#8211;dist-dir /tmp/easy\_install-TG5_T0/virtualenv-1.7.1.2/egg-dist-tmp-4hGv  
> bY  
> warning: no previously-included files matching &#8216;\*.\*&#8217; found under directory &#8216;docs/_templates&#8217;  
> Removing virtualenv 0.9.2 from easy-install.pth file  
> Adding virtualenv 1.7.1.2 to easy-install.pth file  
> Installing virtualenv script to /usr/local/bin
> 
> Installed /usr/local/lib/python2.7/site-packages/virtualenv-1.7.1.2-py2.7.egg  
> Processing dependencies for virtualenv==1.7.1.2  
> Finished processing dependencies for virtualenv==1.7.1.2