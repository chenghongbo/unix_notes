---
title: 使用SAR命令查看系统资源使用情况
author: acheng
layout: post
date: 2011-08-03
url: /blog/sar-examples-linux/
categories:
  - Linux
  - 系统管理
tags:
  - sar
---
SAR是Linux上一个很有用的命令，它不但可以查看系统资源使用情况，像是CPU，内存，磁盘IO等等。  
更重要的是，它还可以查看以前的系统资源占用率（默认可以向前追溯一个月。需要相应的配置，但大部分Linux默认就安装/配置了SAR），这样就可以问题发生以后查看历史记录。

下面是一篇很不错的SAR的使用示例：

http://www.thegeekstuff.com/2011/03/sar-examples/