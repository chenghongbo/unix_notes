---
title: Solaris – 禁用GUI登录界面
author: acheng
layout: post
date: 2010-12-06
excerpt: |
  |
    Solaris 10默认安装完成后会使用图形界面（GUI）来登录。如果不想使用GUI，可以使用下面的命令来使系统启动后自动进入命令行界面：
    
    以root用户登录系统后，打开一个命令行窗口（terminal），在命令行下运行下面的命令来禁止GUI：
    
             /usr/dt/bin/dtconfig -d
    
    若需要恢复GUI登录界面，则运行下面的命令：
    
             /usr/dt/bin/dtconfig -e
url: /blog/disable-gui/
categories:
  - blog
  - Featured
  - Solaris
tags:
  - news
---
Solaris 10默认安装完成后会使用图形界面（GUI）来登录。如果不想使用GUI，可以使用下面的命令来使系统启动后自动进入命令行界面：

以root用户登录系统后，打开一个命令行窗口（terminal），在命令行下运行下面的命令来禁止GUI：

/usr/dt/bin/dtconfig -d

若需要恢复GUI登录界面，则运行下面的命令：

/usr/dt/bin/dtconfig -e