---
title: file name too long error on OpenBSD
author: acheng
layout: post
date: 2012-01-04
url: /blog/file-name-too-long-error-on-openbsd/
categories:
  - blog
  - openbsd
  - 开源应用
---
最近在OpenBSD自带的Apache1.3上总是碰到类似下面这样的错误。

<div>
  [Wed Dec 28 14:15:51 2011] [error] [client 10.249.70.50] (63)File name too long: Cannot map GET /media/ajax/component/boxList/<wbr>filter/featured/limit/all/<wbr>layout/thumbBig/vars/a%253A25%<wbr>253A%257Bs%253A3%253A%2522act%<wbr>2522%253Bs%253A7%253A%<wbr>2522boxList%2522%253Bs%253A3%<wbr>253A%2522mod%2522%253Bs%253A5%<wbr>253A%2522media%2522%253Bs%<wbr>253A4%253A%2522mode%2522%<wbr>253Bs%253A3%253A%2522all%2522%<wbr>253Bs%253A6%253A%2522filter%<wbr>2522%253Bs%253A8%253A%<wbr>2522featured%2522%253Bs%253A5%<wbr>253A%2522limit%2522%253Bs%<wbr>253A3%253A%2522all%2522%253Bs%<wbr>253A6%253A%2522layout%2522%<wbr>253Bs%253A8%253A%2522thumbBig%<wbr>2522%253Bs%253A6%253A%<wbr>2522search%2522%253Bs%253A0%<wbr>253A%2522%2522%253Bs%253A8%<wbr>253A%2522per_page%2522%253Ba%<wbr>253A3%253A%257Bs%253A8%253A%<wbr>2522thumbBig%2522%253Bi%253A6%<wbr>253Bs%253A5%253A%2522thumb%<wbr>2522%253Bi%253A10%253Bs%253A4%<wbr>253A%2522list%2522%253Bi%<wbr>253A4%253B%257Ds%253A11%253A%<wbr>2522show_filter%2522%253Bb%<wbr>253A1%253Bs%253A10%253A%<wbr>2522show_limit%2522%253Bb%<wbr>253A0%253Bs%253A11%253A%<wbr>2522show_layout%2522%253Bb%<wbr>253A1%253Bs%253A11%253A%<wbr>2522show_search%2522%253Bb%<wbr>253A0%253Bs%253A10%253A%<wbr>2522show_pager%2522%253Bb%<wbr>253A0%253Bs%253A9%253A%<wbr>2522show_more%2522%253Bb%<wbr>253A1%253Bs%253A9%253A%<wbr>2522save_page%2522%253Bb%<wbr>253A1%253Bs%253A10%253A%<wbr>2522pager_name%2522%253Bs%<wbr>253A4%253A%2522page%2522%<wbr>253Bs%253A9%253A%<wbr>2522thumbsize%2522%253Bs%<wbr>253A7%253A%2522160&#215;120%2522%<wbr>253Bs%253A9%253A%2522more_<wbr>link%2522%253Bs%253A10%253A%<wbr>2522media%252Flist%2522%253Bs%<wbr>253A2%253A%2522id%2522%253Bs%<wbr>253A9%253A%2522media-box%2522%<wbr>253Bs%253A9%253A%<wbr>2522component%2522%253Bs%<wbr>253A7%253A%2522boxList%2522%<wbr>253Bs%253A4%253A%2522type%<wbr>2522%253BN%253Bs%253A4%253A%<wbr>2522text%2522%253BN%253Bs%<wbr>253A13%253A%2522captionParams%<wbr>2522%253Ba%253A0%253A%257B%<wbr>257Ds%253A7%253A%2522caption%<wbr>2522%253Bs%253A9%253A%2522New%<wbr>2Bmedia%2522%253Bs%253A4%253A%<wbr>2522page%2522%253Bi%253A1%<wbr>253B%257D HTTP/1.1 to file, referer: <a href="http://host/" target="_blank">http://host</a></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr></wbr>
</div>

<div>
  <p>
    折腾了两周时间，最后发现是OpenBSD上的最长路径参数引起的。OpenBSD上路径最长默认为1024字节。Linux上则是4096。所以同样的web应用在Ubuntu+Apache2上没有问题，但在OpenBSD上就不行。
  </p>
  
  <p>
    最后修改了下面两个文件，将PATH_MAX从原来的1024改为2048，然后重新编译内核后解决问题。
  </p>
  
  <p>
    &nbsp;
  </p>
  
  <div>
    ./sys/sys/syslimits.h:46:#<wbr>define        PATH_MAX                 2048   /* max bytes in pathname */</wbr>
  </div>
  
  <div>
    ./include/stdio.h:187:#define   FILENAME_MAX    2048    /* must be <= PATH_MAX <sys/syslimits.h> */
  </div>
  
  <div>
    ./include/stdio.h:193:#define   L_tmpnam        2048 /* XXX must be == PATH_MAX */
  </div>
</div>

<div>
  可参看http://jiarun.org/newpostinthread3083.html来了解整个过程
</div>