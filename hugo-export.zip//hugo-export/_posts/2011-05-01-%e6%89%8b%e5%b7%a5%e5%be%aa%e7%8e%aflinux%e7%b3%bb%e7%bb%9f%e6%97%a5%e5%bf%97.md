---
title: 手工循环Linux系统日志
author: acheng
layout: post
date: 2011-05-01
url: /blog/%e6%89%8b%e5%b7%a5%e5%be%aa%e7%8e%aflinux%e7%b3%bb%e7%bb%9f%e6%97%a5%e5%bf%97/
categories:
  - blog
  - Linux
---
今天发现一台RHEL 5的机器上/var/log/messages日志的大小达到了670MB，而系统整个/var分区的大小才1.7G。这种情况下很容易导致/var分区空间耗尽而影响系统和程序的运行。于是我决定手工压缩这个文件。

由于系统是一直在往/var/log/messages文件中写入信息，因此不能直接用gzip压缩。一个比较好的不办法就是手工调用logrotate程序，让它来进行相应的处理：

#logrotate /etc/logrotate.d/syslog

这个命令会将/var/log/messages文件压缩，并自动产生一个的同名的文件。更重要的是，它会保证这个过程中系统的日志不会丢失。