---
title: openbsd下启用apache
author: acheng
layout: post
date: 2009-06-08
excerpt: |
  今天把系统重新整理了一下。前些天搭建好red5流媒体服务器，今天测试一下。这个视频讲的是如何在openbsd 4.5下启用apache，有配音。
  
  更新：视频存储转回到youku.com
  <embed src='http://player.youku.com/player.php/sid/XMTA2MTQzNDc2/v.swf' quality='high' width='680' height='480' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash'></embed>
url: /blog/openbsd-enable-apache/
categories:
  - 视频
tags:
  - samplevideo
  - sysadmin
---
今天把系统重新整理了一下。前些天搭建好red5流媒体服务器，今天测试一下。这个视频讲的是如何在openbsd 4.5下启用apache，有配音。

更新：视频存储转回到youku.com  


<embed src='http://player.youku.com/player.php/sid/XMTA2MTQzNDc2/v.swf' quality='high' width='480' height='400' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash'>
</embed>