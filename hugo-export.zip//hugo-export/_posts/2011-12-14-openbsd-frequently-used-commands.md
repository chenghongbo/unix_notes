---
title: OpenBSD frequently used commands
author: acheng
layout: post
date: 2011-12-14
url: /blog/openbsd-frequently-used-commands/
categories:
  - openbsd
  - 系统管理
---
在使用系统的时候碰到一些不常用的命令经常要去看man手册。为了免去这个麻烦，最近抽空把自己常用的命令汇总了一下，做成PDF文档。希望对其他的朋友也能有所帮助。

这个文档将会不定期更新，会再增加诸如date，uname等常用命令。

2012.02.27： 更新下载链接，新版修正了前面的版本中的一个笔误（关于使用FLAVOR安装PACKAGE）  
2012.06.18: 更新至v0.9.4版，新增了PF，MISC，TMUX，进程管理，其它也有一些小的更新。

[下载v0.9.4][1]

 [1]: http://www.kdump.cn/content/wp-content/uploads/2012/06/OpenBSD_cheat_sheet-0.9.4.pdf