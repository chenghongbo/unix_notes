---
title: BIND on OpenBSD PPT
author: acheng
layout: post
date: 2010-01-15
excerpt: |
  Here is the PPT file used to record the BIND on OpenBSD video. Written in English.
  Hope you like it.
url: /blog/bind-on-openbsd-ppt/
categories:
  - 视频
tags:
  - download
---
Here is the PPT file used to record the BIND on OpenBSD video. Written in English.  
Hope you like it.