---
title: openbsd网络基本配置
author: acheng
layout: post
date: 2009-06-14
excerpt: |
  这个视频讲述openbsd的基本网络配置，如IP，DNS服务器，DHCP客户端等。
  <embed src='http://player.youku.com/player.php/sid/XMTA0MjcxNDE2/v.swf' quality='high' width='680' height='480' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash'></embed>
url: /blog/openbsd-basic-network/
categories:
  - 视频
tags:
  - network
  - samplevideo
  - sysadmin
---
这个视频讲述openbsd的基本网络配置，如IP，DNS服务器，DHCP客户端等。  


<embed src='http://player.youku.com/player.php/sid/XMTA0MjcxNDE2/v.swf' quality='high' width='480' height='400' align='middle' allowScriptAccess='sameDomain' type='application/x-shockwave-flash'>
</embed>