---
title: OpenBSD上的Apache+SSL
author: acheng
layout: post
date: 2009-10-11
excerpt: |
  本视频介绍如何使用openssl工具生成SSL证书以及如何在apache中使用此证书
  <embed src="http://player.youku.com/player.php/sid/XMTI0NzQ4MTM2/v.swf" quality="high" width="680" height="480" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash"></embed>
url: /blog/apache_ssl/
categories:
  - 视频
tags:
  - samplevideo
  - security
  - sysadmin
---
本视频介绍如何使用openssl工具生成SSL证书以及如何在apache中使用此证书  


<embed src="http://player.youku.com/player.php/sid/XMTI0NzQ4MTM2/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash">
</embed>