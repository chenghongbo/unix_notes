---
title: Ubuntu上配置Postfix使用gmail转发邮件
author: acheng
layout: post
date: 2012-04-01
url: /blog/configure_postfix_relayhost_using_gmail/
categories:
  - Linux
  - 开源应用
  - 系统管理
---
任务：如何配置Ubuntu上的Postfix使用gmail邮件服务器转发邮件  
原因：使用ADSL等方式上网的ubuntu服务器发送的邮件经常被当作垃圾邮件

注：这篇博文不是要配置一个完整的Postfix邮件服务器，只是谈一下如何让它把所有要发送的邮件转交给gmail的邮件服务器来发送，减少发送邮件被当作垃圾邮件的几率。你需要有一个gmail的账户。

如何做：

1. 如果你的Ubuntu上没有Postfix，先安装。  
`sudo apt-get install postfix `(在安装的过程中会提示你Postfix的使用场合，选择Internet Configuration)

2. 创建一个包含有你的gmail邮件服务器地址及你的账户信息的文件，这里以/etc/postfix/relay_passwd为例。内容如下：

` smtp.gmail.com:587 my_account@gmail.com:My_pass`

3. 运行postmap命令，生成postmap database：  
`postmap /etc/postfix/relay_passwd`

4. 在/etc/postfix/main.cf中添加如下内容：

`## To use gmail MTA as relay host 2012, 03/28<br />
relayhost = smtp.gmail.com:587<br />
smtp_sasl_password_maps = hash:/etc/postfix/relay_passwd<br />
smtpd_use_tls = yes<br />
smtp_use_tls = yes<br />
smtpd_tls_auth_only = no<br />
smtp_sasl_auth_enable = yes<br />
smtp_tls_note_starttls_offer = yes<br />
smtpd_sasl_local_domain = $myhostname<br />
smtp_sasl_security_options = noanonymous<br />
## end addition by acheng`

5. 重启postfix

`/etc/init.d/postfix restart`