---
title: ComixWall 4.6 installation demo
author: acheng
layout: post
date: 2010-01-15
excerpt: |
  |
    ComixWall是一个基于OpenBSD的ISG（互联网安全网关），也可以说是UTM（同意威胁管理）系统， 它集成了数据包过滤，HTTP/SMTP/POP3代理，IDS和IPS以及VPN等等多项网络安全相关应用。本视频演示ComixWall的安装过程。同时，ComixWall项目于12月8号发表声明，表示项目将于今年年终终止，不在发布新的发行版。所以这次我们演示的4.6也将成为最后一个。但我仍然要说这个系统是值得大家尝试和使用的。
url: /blog/comixwall-4-6-installation-demo/
categories:
  - 视频
tags:
  - comixwall
  - network
  - samplevideo
  - security
  - sysadmin
---
更新：ComixWall项目已于2010年终止，4.6版最最后版本

ComixWall是一个基于OpenBSD的ISG（互联网安全网关），也可以说是UTM（同意威胁管理）系统， 它集成了数据包过滤，HTTP/SMTP/POP3代理，IDS和IPS以及VPN等等多项网络安全相关应用。本视频演示ComixWall的安装过程。同时，ComixWall项目于12月8号发表声明，表示项目将于今年年终终止，不在发布新的发行版。所以这次我们演示的4.6也将成为最后一个。但我仍然要说这个系统是值得大家尝试和使用的。