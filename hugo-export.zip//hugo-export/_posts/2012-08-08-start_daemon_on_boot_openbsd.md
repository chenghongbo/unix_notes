---
title: OpenBSD进程的开机启动
author: acheng
layout: post
date: 2012-08-08
url: /blog/start_daemon_on_boot_openbsd/
categories:
  - blog
  - openbsd
  - 系统管理
tags:
  - openbsd
---
OpenBSD上守护进程的开机启动由/etc/rc.conf.local来控制。需要程序随机器启动，需要相应编辑此文件。

OpenBSD上的守护进程一般分为系统自带以及用户安装两种。系统自带进程，如ftpd, relayd，named等；用户安装的守护进程则是用户自己通过pkg_add安装的程序所带的守护进程。

今天我们先谈一下如何开机启动系统自带的进程。以named为例。

对于这一类的进程，/etc/rc.conf文件下一般会有相应的变量来控制它是否随机器启动而运行。对于named来说：

<div class="sb_info">
  $ grep named /etc/rc.conf<br /> named_flags=NO # for normal use: &#8220;&#8221;
</div>

named默认是不会随机器启动的。同时这个文件也给出提示，如果你想要启动它，把这一行改成：

<div class="sb_info">
  named_flags=&#8221;&#8221;
</div>

即可。

但是我们不应该直接改动/etc/rc.conf文件，虽然直接改也能生效。推荐的方法是编辑/etc/rc.conf.local文件，把这一行放入其中，也能起到同样的效果。这样做的好处是，升级系统的时候，你的配置不会被覆盖掉（/etc/rc.conf会在升级时被覆盖）。

如果你不想重启系统，可以看一下/etc/rc.d目录下是否有启动脚本。对于named来说，我们可以直接运行：

<div class="sb_tip">
  /etc/rc.d/named start
</div>

以后我们再谈如何启动用户自己安装的守护进程。