---
title: ComixWall4.6安装演示
author: acheng
layout: post
date: 2009-12-11
excerpt: |
  ComixWall是一个基于OpenBSD的ISG（互联网安全网关），也可以说是UTM（同意威胁管理）系统， 它集成了数据包过滤，HTTP/SMTP/POP3代理，IDS和IPS以及VPN等等多项网络安全相关应用。本视频演示ComixWall的安装过程。同时，ComixWall项目于12月8号发表声明，表示项目将于今年年终终止，不在发布新的发行版。所以这次我们演示的4.6也将成为最后一个。但我仍然要说这个系统是值得大家尝试和使用的。
  
  <embed src="http://player.youku.com/player.php/sid/XMTM3NzMzNjgw/v.swf" quality="high" width="680" height="480" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash"></embed>
url: /blog/openbsd46-installation/
categories:
  - 视频
tags:
  - network
  - samplevideo
  - security
  - sysadmin
---
ComixWall是一个基于OpenBSD的ISG（互联网安全网关），也可以说是UTM（同意威胁管理）系统， 它集成了数据包过滤，HTTP/SMTP/POP3代理，IDS和IPS以及VPN等等多项网络安全相关应用。本视频演示ComixWall的安装过程。同时，ComixWall项目于12月8号发表声明，表示项目将于今年年终终止，不在发布新的发行版。所以这次我们演示的4.6也将成为最后一个。但我仍然要说这个系统是值得大家尝试和使用的。

<embed src="http://player.youku.com/player.php/sid/XMTM3NzMzNjgw/v.swf" quality="high" width="680" height="480" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash">
</embed>