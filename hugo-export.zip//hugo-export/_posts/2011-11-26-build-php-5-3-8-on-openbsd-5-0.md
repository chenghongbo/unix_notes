---
title: build php-5.3.8 on OpenBSD 5.0
author: acheng
layout: post
date: 2011-11-26
url: /blog/build-php-5-3-8-on-openbsd-5-0/
categories:
  - openbsd
  - 开源应用
  - 系统管理
---
由于要配合nginx使用php-fpm，于是自己编译php-5.3.8。

在make的时候出现如下错误：

ext/iconv/iconv.c:615: undefined reference to \`iconv&#8217;

google了一下，说是在make的时候要加上参数 EXTRA_CFLAGS=-liconv,或者是[修改Makefile][1]，但是依然不行。

最后，删除config.cache, 运行make clean，加上“&#8211;with-iconv=/usr/local”参数重新configure，然后make &&  make install 成功。

configure参数如下，仅供参考：

<pre>./configure' '--enable-fpm' '--with-fpm-user=_nginx' '--with-fpm-group=_nginx' \
'--enable-mbstring' '--with-mysqli' '--with-mysql' '--with-pdo-mysql' '--with--openssl' \
'--with-curl' '--with-xsl' '--enable-mbstring' '--with-zlib' '--with-bz2' '--with-mhash' \
'--with-mcrypt' '--with-iconv=/usr/local'

2011/11/29 更新：目前已经有php-fpm软件包，无需自己编译了。</pre>

 [1]: http://www.opensoce.com/?p=3310