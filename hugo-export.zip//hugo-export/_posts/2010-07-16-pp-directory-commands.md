---
title: OpenBSD预备课程 – 常用目录命令
author: acheng
layout: post
date: 2010-07-16
excerpt: |
  |
    这个视频时OpenBSD常用命令中的第二篇，简述和目录操作相关的命令。比如，如何从一个目录切换到另外一个目录，如何创建或删除目录等。
url: /blog/pp-directory-commands/
categories:
  - 视频
tags:
  - samplevideo
---
这个视频时OpenBSD常用命令中的第二篇，简述和目录操作相关的命令。比如，如何从一个目录切换到另外一个目录，如何创建或删除目录等。

<div id="jw_wrap_1279275122954">
  <span></span>
</div>

&nbsp;