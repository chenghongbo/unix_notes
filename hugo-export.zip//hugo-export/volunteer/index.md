---
title: 志愿活动
author: acheng
layout: page
date: 2013-02-23
---
&nbsp;

可达书院愿以自己的技术特长，为公益组织和农民工子弟学校提供志愿IT支持服务或培训。

具体流程请使用电子邮件与我们联系。

我们能提供的志愿服务有：

[unordered_list style=&#8221;tick&#8221;]

  * 信息化咨询
  * 网站与电子邮件系统搭建
  * 计算机入门知识培训
  * 操作系统培训（ubuntu Linux，OpenBSD以及Windows &#8230;）
  * 各类常用计算机软件培训，如微软Office系列
  * 编程语言培训
  * &#8230;&#8230;

[/unordered_list]

可使用下面的表格联系可达书院：

[contact_form email=&#8221;acheng@kdump.cn&#8221; subject=&#8221;IT志愿活动咨询&#8221;]